import { AccessDenied } from "./_components/AccessDenied";

export default function ForbiddenPage() { return <AccessDenied status={403}/>; }
