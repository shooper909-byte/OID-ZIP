import { AccessDenied } from "./_components/AccessDenied";

export default function UnauthorizedPage() { return <AccessDenied status={401}/>; }
