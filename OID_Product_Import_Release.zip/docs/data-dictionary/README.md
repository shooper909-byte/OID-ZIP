# OID Data Dictionary — v1 domains

- Product / SKU / ProductGate: product identity and gated commercial eligibility.
- Supplier / SupplierProduct: supplier identity, product relationships, qualification state.
- PurchaseOrder / Receipt / ReceiptItem / Lot: physical procurement and traceability chain.
- Laboratory / Sample / TestOrder / TestResult: independent testing chain and human review.
- Document / DocumentLink / EntityLink: controlled evidence and cross-record relationships.
- InventoryMovement / Allocation: movement-authoritative inventory and released-only allocation.
- Exception / Action / Capa / Decision: risk ownership, corrective work, and management reasoning.
- Organization / CustomerOrder / CustomerOrderItem: qualified-organization commercial intelligence while minimizing copied personal data.
- MarketObservation / ResearchSource / IntelligenceQuery: market/scientific evidence and Ask OID history.
- ImportBatch / MigrationConflict / LegacyImportMap: controlled legacy-data migration.
- AuditLog: immutable history of material system actions.
