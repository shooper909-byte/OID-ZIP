# OID recovery status — 2026-09-03

## Source identity

This recovery package was created from Shelby's uploaded `oid-app.zip`. The source matches the August 11, 2026 controlled-staging baseline, not the later supplier-entry build that was running in Azure.

The uploaded source remains a usable recovery baseline. It contains the OID data model, migrations, RBAC, audit controls, supplier and lot views, document controls, inventory allocation services, testing review services, and Azure deployment infrastructure.

## Recovered supplier workflow

- Added `POST /api/v1/suppliers` with schema validation, Founder/Procurement permission enforcement, human-actor enforcement, rate limiting, OID supplier-number generation, and an immutable audit entry.
- Added the supplier-entry form and empty-state guidance.
- Changed `Referrer-Policy` from `no-referrer` to `same-origin` so Azure Container Apps Easy Auth can validate same-origin browser mutations.
- Kept the application's exact-origin CSRF validation enabled.
- Added safe client handling for JSON, HTML, and empty API error responses.

## Validation completed

- Unit tests: 23 passed.
- TypeScript type-check: passed.
- Next.js 16.3.0 production build: passed.
- Source secret scan: passed.
- Container hardening check: passed.
- PostgreSQL integration suite: not run because this recovery environment does not have the private OID test database or a local PostgreSQL service.

## Deployment status

No Azure resource, database, identity, or live application change was made. The recovered source must not replace the live staging image until database-backed integration testing and a controlled deployment/rollback review are complete.
