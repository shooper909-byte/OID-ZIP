ALTER TABLE "TestOrder"
ADD COLUMN "isIndependent" boolean NOT NULL DEFAULT false;
