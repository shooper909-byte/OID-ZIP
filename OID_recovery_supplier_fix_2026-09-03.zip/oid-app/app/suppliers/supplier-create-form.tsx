"use client";

import { FormEvent, useState } from "react";
import { readApiResponse } from "../../lib/http/client";

type CreatedSupplier = { supplier: { id: string; oidCode: string; legalName: string } };

export default function SupplierCreateForm() {
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    const form = new FormData(event.currentTarget);
    const body = Object.fromEntries(form.entries());

    try {
      const response = await fetch("/api/v1/suppliers", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      const result = await readApiResponse<CreatedSupplier>(response);
      if (!result.ok) {
        setError(result.error);
        return;
      }
      window.location.assign(`/suppliers/${result.data.supplier.id}`);
    } catch {
      setError("OID could not reach the server. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <details className="card create-panel">
      <summary>Add supplier</summary>
      <form className="form-grid" onSubmit={submit}>
        <label>
          Legal name <span aria-hidden="true">*</span>
          <input name="legalName" required minLength={2} maxLength={200} autoComplete="organization" />
        </label>
        <label>
          Trade name
          <input name="tradeName" maxLength={200} />
        </label>
        <label>
          Supplier type
          <select name="supplierType" defaultValue="UNKNOWN">
            <option value="UNKNOWN">Unknown / not confirmed</option>
            <option value="MANUFACTURER">Manufacturer</option>
            <option value="TRADING_COMPANY">Trading company</option>
            <option value="DISTRIBUTOR">Distributor</option>
            <option value="BROKER">Broker</option>
          </select>
        </label>
        <label>
          Payment beneficiary
          <input name="paymentBeneficiaryName" maxLength={200} />
        </label>
        <label>
          Country
          <input name="country" maxLength={100} />
        </label>
        <label>
          City
          <input name="city" maxLength={100} />
        </label>
        <label>
          State / region
          <input name="region" maxLength={100} />
        </label>
        <label>
          Website
          <input name="website" type="url" maxLength={500} placeholder="https://" />
        </label>
        <div className="form-actions">
          <button className="button primary" type="submit" disabled={submitting}>
            {submitting ? "Saving…" : "Save supplier"}
          </button>
          {error ? <p className="form-error" role="alert">{error}</p> : null}
        </div>
      </form>
    </details>
  );
}
