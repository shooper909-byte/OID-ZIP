import { db } from "../../lib/database";
import SupplierCreateForm from "./supplier-create-form";

export const dynamic = "force-dynamic";

export default async function Page() {
  const rows = await db.supplier.findMany({ orderBy: { legalName: "asc" }, take: 100 });
  return <>
    <div className="page-head">
      <div><div className="eyebrow">Supplier Intelligence</div><h1>Suppliers</h1></div>
    </div>
    <SupplierCreateForm />
    {rows.length ? <table className="table">
      <thead><tr><th>OID</th><th>Supplier</th><th>Type</th><th>Qualification</th><th>Risk</th></tr></thead>
      <tbody>{rows.map(r => <tr key={r.id}><td className="code"><a href={`/suppliers/${r.id}`}>{r.oidCode}</a></td><td>{r.legalName}</td><td>{r.supplierType}</td><td><span className="badge">{r.qualificationStatus}</span></td><td>{r.riskLevel ?? "—"}</td></tr>)}</tbody>
    </table> : <div className="card empty-state"><strong>No suppliers yet.</strong><p className="muted">Add the first vendor to begin qualification, purchasing, receiving, and lot traceability.</p></div>}
  </>;
}
