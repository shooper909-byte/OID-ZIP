import { NextResponse } from "next/server";
import { z } from "zod";
import { actorForServerRequest, requireHumanActor } from "../../../../lib/auth";
import { db } from "../../../../lib/database";
import { nextOidCode } from "../../../../lib/oid-identifiers/counter";
import { PERMISSIONS, requirePermission } from "../../../../lib/permissions";
import { assertMutationOrigin, safeApiError } from "../../../../lib/security/request";
import { consumeRateLimit } from "../../../../lib/security/rate-limit";

const optionalText = (max: number) => z.string().trim().max(max).optional().transform((value) => value || undefined);
const optionalUrl = z.string().trim().max(500).optional().transform((value, context) => {
  if (!value) return undefined;
  try {
    const parsed = new URL(value);
    if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error();
    return parsed.toString();
  } catch {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "Website must be a valid HTTP or HTTPS URL." });
    return z.NEVER;
  }
});

const Body = z.object({
  legalName: z.string().trim().min(2).max(200),
  tradeName: optionalText(200),
  supplierType: z.enum(["MANUFACTURER", "TRADING_COMPANY", "DISTRIBUTOR", "BROKER", "UNKNOWN"]),
  country: optionalText(100),
  city: optionalText(100),
  region: optionalText(100),
  website: optionalUrl,
  paymentBeneficiaryName: optionalText(200),
}).strict();

export async function POST(request: Request) {
  try {
    assertMutationOrigin(request);
    const actor = await actorForServerRequest(request);
    requireHumanActor(actor);
    requirePermission(actor.permissions, PERMISSIONS.SUPPLIER_WRITE);
    if (!consumeRateLimit(`supplier-create:${actor.userId}`, 20, 60_000).allowed) throw new Error("RATE_LIMITED");
    const input = Body.parse(await request.json());

    const supplier = await db.$transaction(async (tx) => {
      const created = await tx.supplier.create({
        data: {
          oidCode: await nextOidCode(tx, "SUP"),
          legalName: input.legalName,
          tradeName: input.tradeName,
          supplierType: input.supplierType,
          country: input.country,
          city: input.city,
          region: input.region,
          website: input.website,
          paymentBeneficiaryName: input.paymentBeneficiaryName,
          ownerUserId: actor.userId,
        },
      });
      await tx.auditLog.create({
        data: {
          oidCode: await nextOidCode(tx, "AUD"),
          eventType: "CREATE",
          userId: actor.userId,
          entityType: "SUPPLIER",
          entityId: created.id,
          newValues: {
            oidCode: created.oidCode,
            legalName: created.legalName,
            supplierType: created.supplierType,
            qualificationStatus: created.qualificationStatus,
          },
          reason: "Supplier record created",
        },
      });
      return created;
    });

    return NextResponse.json({ supplier }, { status: 201 });
  } catch (error) {
    return safeApiError(error, 400);
  }
}
