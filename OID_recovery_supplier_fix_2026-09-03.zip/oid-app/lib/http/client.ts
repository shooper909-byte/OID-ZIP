export type ApiResult<T> =
  | { ok: true; data: T }
  | { ok: false; error: string; status: number };

export async function readApiResponse<T>(response: Response): Promise<ApiResult<T>> {
  const text = await response.text();
  let payload: unknown;

  if (text) {
    try {
      payload = JSON.parse(text);
    } catch {
      payload = undefined;
    }
  }

  if (!response.ok) {
    const apiError =
      payload && typeof payload === "object" && "error" in payload && typeof payload.error === "string"
        ? payload.error
        : undefined;
    return {
      ok: false,
      error: apiError ?? `Request failed (${response.status}${response.statusText ? ` ${response.statusText}` : ""})`,
      status: response.status,
    };
  }

  if (payload === undefined) {
    return { ok: false, error: "The server returned an unreadable response.", status: response.status };
  }

  return { ok: true, data: payload as T };
}
