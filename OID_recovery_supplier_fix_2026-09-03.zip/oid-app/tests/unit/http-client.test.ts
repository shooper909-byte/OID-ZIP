import { describe, expect, it } from "vitest";
import { readApiResponse } from "../../lib/http/client";

describe("API client responses", () => {
  it("returns the API error from a JSON response", async () => {
    const result = await readApiResponse(new Response(JSON.stringify({ error: "FORBIDDEN:supplier.write" }), {
      status: 403,
      headers: { "content-type": "application/json" },
    }));
    expect(result).toEqual({ ok: false, error: "FORBIDDEN:supplier.write", status: 403 });
  });

  it("turns an Azure HTML or empty rejection into a readable error", async () => {
    const result = await readApiResponse(new Response("<!doctype html><title>Forbidden</title>", {
      status: 403,
      statusText: "Forbidden",
      headers: { "content-type": "text/html" },
    }));
    expect(result).toEqual({ ok: false, error: "Request failed (403 Forbidden)", status: 403 });
  });

  it("returns parsed JSON after a successful request", async () => {
    const result = await readApiResponse<{ supplier: { id: string } }>(new Response(JSON.stringify({ supplier: { id: "supplier-1" } }), { status: 201 }));
    expect(result).toEqual({ ok: true, data: { supplier: { id: "supplier-1" } } });
  });
});
