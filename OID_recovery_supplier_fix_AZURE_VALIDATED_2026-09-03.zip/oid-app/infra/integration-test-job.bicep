targetScope = 'resourceGroup'

@description('Immutable or uniquely tagged integration-test image in the existing OID registry.')
param testImage string

param location string = resourceGroup().location
param jobName string = 'oid-staging-integration-20260903'
param managedEnvironmentName string = 'oid-staging-cae-qgvnukjcy7jwk'
param managedIdentityName string = 'oid-staging-app-mi-qgvnukjcy7jwk'
param registryName string = 'oidstagingacrqgvnukjcy7jwk'
param keyVaultName string = 'oid-staging-kv-qgvnukjcy'

resource environment 'Microsoft.App/managedEnvironments@2025-01-01' existing = {
  name: managedEnvironmentName
}

resource identity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' existing = {
  name: managedIdentityName
}

resource registry 'Microsoft.ContainerRegistry/registries@2023-07-01' existing = {
  name: registryName
}

resource keyVault 'Microsoft.KeyVault/vaults@2023-07-01' existing = {
  name: keyVaultName
}

resource runtimeDatabaseSecret 'Microsoft.KeyVault/vaults/secrets@2023-07-01' existing = {
  name: 'oid-runtime-database-url'
  parent: keyVault
}

resource integrationJob 'Microsoft.App/jobs@2025-01-01' = {
  name: jobName
  location: location
  tags: {
    environment: 'staging'
    dataClassification: 'synthetic-only'
    purpose: 'oid-integration-validation'
    schedule: 'manual-only'
  }
  identity: {
    type: 'UserAssigned'
    userAssignedIdentities: {
      '${identity.id}': {}
    }
  }
  properties: {
    environmentId: environment.id
    configuration: {
      triggerType: 'Manual'
      replicaRetryLimit: 0
      replicaTimeout: 1800
      manualTriggerConfig: {
        parallelism: 1
        replicaCompletionCount: 1
      }
      registries: [
        {
          server: registry.properties.loginServer
          identity: identity.id
        }
      ]
      secrets: [
        {
          name: 'managed-database-url'
          keyVaultUrl: runtimeDatabaseSecret.properties.secretUri
          identity: identity.id
        }
      ]
    }
    template: {
      containers: [
        {
          name: 'oid-integration-test'
          image: testImage
          env: [
            {
              name: 'MANAGED_DATABASE_URL'
              secretRef: 'managed-database-url'
            }
          ]
          resources: {
            cpu: json('0.5')
            memory: '1Gi'
          }
        }
      ]
    }
  }
}

output integrationTestJobName string = integrationJob.name
