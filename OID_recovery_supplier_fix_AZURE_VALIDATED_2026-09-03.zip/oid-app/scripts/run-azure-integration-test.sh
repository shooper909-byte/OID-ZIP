#!/bin/sh
set -eu

if [ -z "${MANAGED_DATABASE_URL:-}" ]; then
  echo "AZURE_INTEGRATION_FAILED:MISSING_MANAGED_DATABASE_URL" >&2
  exit 1
fi

echo "OID_AZURE_INTEGRATION_START"
node scripts/check-managed-database.mjs

OID_TEST_PGDATA="$(mktemp -d /tmp/oid-integration-pgdata.XXXXXX)"
export PGDATA="$OID_TEST_PGDATA"
export PGHOST="127.0.0.1"
export PGPORT="55432"
export PGUSER="node"
export OID_STORAGE_BACKEND="local"
export OID_STORAGE_ROOT="/tmp/oid-integration-documents"
export DATABASE_URL="postgresql://node@127.0.0.1:55432/oid_integration?schema=public"

stop_postgres() {
  if [ -f "$PGDATA/postmaster.pid" ]; then
    pg_ctl -D "$PGDATA" -m fast -w stop >/dev/null 2>&1 || true
  fi
}
trap stop_postgres EXIT INT TERM

initdb -D "$PGDATA" --username="$PGUSER" --auth=trust --encoding=UTF8 --no-locale >/dev/null
if ! pg_ctl -D "$PGDATA" -l "$PGDATA/server.log" -o "-h 127.0.0.1 -p $PGPORT -k $PGDATA" -w start >/dev/null; then
  echo "AZURE_INTEGRATION_FAILED:DISPOSABLE_POSTGRES_START" >&2
  sed -n '1,120p' "$PGDATA/server.log" >&2
  exit 1
fi
createdb oid_integration

node node_modules/prisma/build/index.js migrate deploy
node node_modules/tsx/dist/cli.mjs prisma/seed.ts
node node_modules/vitest/vitest.mjs run tests/integration/oid-workflow.test.ts

# Re-check the managed service after the disposable write tests. Matching
# before/after summaries provide evidence that the real database stayed read-only.
node scripts/check-managed-database.mjs

echo "OID_AZURE_INTEGRATION_PASS"
