import { PrismaClient } from "@prisma/client";

if (!process.env.MANAGED_DATABASE_URL) {
  console.error("MANAGED_DB_CHECK_FAILED:MISSING_DATABASE_URL");
  process.exit(1);
}

const db = new PrismaClient({ datasources: { db: { url: process.env.MANAGED_DATABASE_URL } } });

try {
  const [roleRows, migrationRows, tableRows, businessCounts] = await Promise.all([
    db.$queryRaw`SELECT current_user, rolsuper, rolcreatedb, rolcreaterole, rolreplication, rolbypassrls, has_schema_privilege(current_user, 'public', 'CREATE') AS can_create_in_public FROM pg_roles WHERE rolname = current_user`,
    db.$queryRaw`SELECT count(*)::int AS count FROM public."_prisma_migrations" WHERE finished_at IS NOT NULL AND rolled_back_at IS NULL`,
    db.$queryRaw`SELECT count(*)::int AS count FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE'`,
    Promise.all([db.supplier.count(), db.product.count(), db.lot.count(), db.testResult.count(), db.auditLog.count()]),
  ]);

  const role = roleRows[0];
  if (!role || role.current_user !== "oid_runtime") throw new Error("RUNTIME_ROLE_MISMATCH");
  if (role.rolsuper || role.rolcreatedb || role.rolcreaterole || role.rolreplication || role.rolbypassrls || role.can_create_in_public) {
    throw new Error("RUNTIME_ROLE_OVERPRIVILEGED");
  }

  console.log(JSON.stringify({
    check: "managed-private-postgresql",
    status: "PASS",
    runtimeRole: role.current_user,
    runtimeDdlDenied: true,
    appliedMigrations: migrationRows[0].count,
    applicationTables: tableRows[0].count,
    recordCounts: {
      suppliers: businessCounts[0],
      products: businessCounts[1],
      lots: businessCounts[2],
      testResults: businessCounts[3],
      auditEvents: businessCounts[4],
    },
  }));
} catch (error) {
  const known = error instanceof Error && ["RUNTIME_ROLE_MISMATCH", "RUNTIME_ROLE_OVERPRIVILEGED"].includes(error.message)
    ? error.message
    : "QUERY_OR_CONNECTIVITY_FAILURE";
  console.error(`MANAGED_DB_CHECK_FAILED:${known}`);
  process.exitCode = 1;
} finally {
  await db.$disconnect();
}
