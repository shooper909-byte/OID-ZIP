# OID recovery status — 2026-09-03

## Source identity

This recovery package was created from Shelby's uploaded `oid-app.zip`. The source matches the August 11, 2026 controlled-staging baseline, not the later supplier-entry build that was running in Azure.

The uploaded source remains a usable recovery baseline. It contains the OID data model, migrations, RBAC, audit controls, supplier and lot views, document controls, inventory allocation services, testing review services, and Azure deployment infrastructure.

## Recovered supplier workflow

- Added `POST /api/v1/suppliers` with schema validation, Founder/Procurement permission enforcement, human-actor enforcement, rate limiting, OID supplier-number generation, and an immutable audit entry.
- Added the supplier-entry form and empty-state guidance.
- Changed `Referrer-Policy` from `no-referrer` to `same-origin` so Azure Container Apps Easy Auth can validate same-origin browser mutations.
- Kept the application's exact-origin CSRF validation enabled.
- Added safe client handling for JSON, HTML, and empty API error responses.

## Validation completed

- Unit tests: 23 passed.
- TypeScript type-check: passed.
- Next.js 16.3.0 production build: passed.
- Source secret scan: passed.
- Container hardening check: passed.
- PostgreSQL integration suite: passed in the existing Azure Container Apps environment on 2026-09-03.
- Successful execution: `oid-staging-integration-20260903-a18nlam`.
- Execution window: 2026-09-03 20:45:50–20:46:40 UTC.
- Tested image: `oidstagingacrqgvnukjcy7jwk.azurecr.io/oid-integration-test@sha256:10a0cd35d1256209b77d2ca4b9e72e5943edd56745610be0e92ab54595dea921`.
- The managed private PostgreSQL check reported `PASS` using the restricted `oid_runtime` role with DDL denied, 6 applied migrations, and 45 application tables.
- The write-heavy supplier, receipt, lot, testing, release, allocation, exception/CAPA, document-integrity, authorization, and session-revocation workflow ran only against the runner's disposable PostgreSQL 17 database.
- The runner completed with `OID_AZURE_INTEGRATION_PASS`.

## Azure execution notes

- A first diagnostic execution failed before database access because a per-execution image override omitted `MANAGED_DATABASE_URL`. No managed-database query or application workflow ran in that attempt.
- The manual test job's saved image was then updated to the immutable tested digest while retaining `MANAGED_DATABASE_URL` → `managed-database-url`.
- The corrected execution was started normally from the saved job definition and succeeded.
- The emergency administrator retains `Contributor` only at the `oid-staging-rg` resource-group scope. Temporary root-scope elevation was removed after access recovery.

## Deployment status

The recovered source is now a database-integration-tested recovery candidate. The manual integration-test job was updated to the immutable tested image, but the live OID Container App was not replaced, restarted, or repointed.

The integration runner remains manual-only and reuses the existing OID managed identity. It requires no new database credentials and no broader Key Vault permission. The managed database checks are read-only; workflow writes occurred only in the runner's disposable PostgreSQL 17 instance.

The final recovery ZIP may be retained and used for controlled deployment planning. A live application rollout still requires an explicit deployment and rollback decision because the recovered source originated from the August 11 controlled-staging baseline rather than the later image previously running in Azure.
