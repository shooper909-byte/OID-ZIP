<?php
/**
 * License management — activation, validation, status tracking.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CM_License {

    private static $instance = null;
    private $api;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->api = new CM_API_Client();
    }

    public function get_key() {
        return get_option( 'cm_license_key', '' );
    }

    public function get_token() {
        return get_option( 'cm_license_token', '' );
    }

    public function get_status() {
        return get_option( 'cm_license_status', 'inactive' );
    }

    public function get_plan() {
        return get_option( 'cm_license_plan', '' );
    }

    public function get_scan_frequency() {
        return get_option( 'cm_license_scan_frequency', '' );
    }

    public function is_active() {
        return 'active' === $this->get_status();
    }

    /**
     * Activate license against SaaS API.
     */
    public function activate( $license_key ) {
        $license_key = sanitize_text_field( trim( $license_key ) );
        if ( empty( $license_key ) ) {
            return array( 'success' => false, 'message' => __( 'Please enter a license key.', 'compliance-monitor' ) );
        }

        $site_url = home_url();
        $response = $this->api->validate_license( $license_key, $site_url );

        if ( ! $response['success'] ) {
            $status = isset( $response['status'] ) ? $response['status'] : 'invalid';
            update_option( 'cm_license_key', $license_key );
            update_option( 'cm_license_status', $status );
            delete_option( 'cm_license_token' );

            return array(
                'success' => false,
                'status'  => $status,
                'message' => $response['error'],
            );
        }

        $data = $response['data'];
        update_option( 'cm_license_key', $license_key );
        update_option( 'cm_license_status', 'active' );
        update_option( 'cm_license_token', $data['token'] );
        update_option( 'cm_license_plan', $data['license']['plan'] );
        update_option( 'cm_license_expires', $data['license']['expiresAt'] );

        if ( ! empty( $data['license']['scanFrequency'] ) ) {
            update_option( 'cm_license_scan_frequency', $data['license']['scanFrequency'] );
        }

        // Push feature flags into Beacon Checkout when present.
        if ( ! empty( $data['entitlements'] ) && is_array( $data['entitlements'] )
            && class_exists( 'Beacon_SC_Entitlements' ) ) {
            Beacon_SC_Entitlements::store( $data['entitlements'] );
        }

        return array(
            'success' => true,
            'status'  => 'active',
            'message' => __( 'License activated successfully.', 'compliance-monitor' ),
            'plan'    => $data['license']['plan'],
        );
    }

    /**
     * Re-validate stored license (e.g., before scan).
     */
    public function revalidate() {
        $key = $this->get_key();
        if ( empty( $key ) ) {
            return false;
        }
        $result = $this->activate( $key );
        return $result['success'];
    }

    public function deactivate() {
        if ( function_exists( 'cm_report_lifecycle_event' ) ) {
            cm_report_lifecycle_event( 'license_deactivated' );
        }
        delete_option( 'cm_license_token' );
        update_option( 'cm_license_status', 'inactive' );
        CM_Scheduler::unschedule();
        CM_Collect_Worker::unschedule();
    }

    public function get_status_label() {
        $status = $this->get_status();
        $labels = array(
            'active'            => __( 'Active', 'compliance-monitor' ),
            'expired'           => __( 'Expired', 'compliance-monitor' ),
            'invalid'           => __( 'Invalid', 'compliance-monitor' ),
            'canceled'          => __( 'Canceled', 'compliance-monitor' ),
            'domain_mismatch'   => __( 'Domain Mismatch', 'compliance-monitor' ),
            'site_limit'        => __( 'Site Limit Reached', 'compliance-monitor' ),
            'payment_required'  => __( 'Payment Required', 'compliance-monitor' ),
            'inactive'          => __( 'Inactive', 'compliance-monitor' ),
        );
        return isset( $labels[ $status ] ) ? $labels[ $status ] : ucfirst( $status );
    }

    public function get_status_class() {
        $status = $this->get_status();
        $classes = array(
            'active'            => 'cm-status-active',
            'expired'           => 'cm-status-error',
            'invalid'           => 'cm-status-error',
            'canceled'          => 'cm-status-error',
            'domain_mismatch'   => 'cm-status-error',
            'site_limit'        => 'cm-status-warning',
            'payment_required'  => 'cm-status-error',
            'inactive'          => 'cm-status-inactive',
        );
        return isset( $classes[ $status ] ) ? $classes[ $status ] : 'cm-status-inactive';
    }
}
