<?php
/**
 * Admin notice helpers.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function cm_brand_logo_url() {
    return CM_PLUGIN_URL . 'assets/images/testament-technologies-logo.png';
}

/**
 * Small icon for the WP Admin sidebar.
 * WordPress renders add_menu_page() image URLs as unconstrained <img> tags,
 * so never pass the full brand logo here.
 */
function cm_menu_icon_url() {
    return CM_PLUGIN_URL . 'assets/images/menu-icon.png';
}

/**
 * Resolve the Beacon SaaS API base URL.
 *
 * Priority:
 *   1. CM_API_BASE_URL constant (define in wp-config.php) — ops/hosting override.
 *   2. Admin setting saved on the Beacon → License screen (cm_api_base_url option).
 *   3. The production Beacon SaaS API default.
 *
 * @return string API base URL with any trailing slash removed.
 */
function cm_get_api_base_url() {
    if ( defined( 'CM_API_BASE_URL' ) && CM_API_BASE_URL ) {
        return rtrim( CM_API_BASE_URL, '/' );
    }

    $option = get_option( 'cm_api_base_url', '' );
    if ( is_string( $option ) && '' !== trim( $option ) ) {
        return rtrim( trim( $option ), '/' );
    }

    return CM_DEFAULT_API_BASE_URL;
}

/**
 * Whether the API URL is fixed by a wp-config.php constant (so it can't be
 * edited from the admin screen).
 *
 * @return bool
 */
function cm_api_base_url_is_locked() {
    return defined( 'CM_API_BASE_URL' ) && (bool) CM_API_BASE_URL;
}

/**
 * Current WP Admin user for lifecycle audit events.
 *
 * @return array{login: string, email: string}
 */
function cm_current_wp_actor() {
    if ( ! function_exists( 'wp_get_current_user' ) ) {
        return array(
            'login' => '',
            'email' => '',
        );
    }
    $user = wp_get_current_user();
    if ( ! $user || ! $user->ID ) {
        return array(
            'login' => '',
            'email' => '',
        );
    }
    return array(
        'login' => (string) $user->user_login,
        'email' => (string) $user->user_email,
    );
}

/**
 * Best-effort phone-home for activate/deactivate/uninstall. Never throws.
 *
 * @param string $event installed|activated|deactivated|uninstalled|updated|license_deactivated
 * @param string $plugin_slug Plugin catalog slug or WP basename.
 * @param string $plugin_version Optional version.
 * @param string $plugin_name Optional display name.
 * @return void
 */
function cm_report_lifecycle_event( $event, $plugin_slug = 'compliance-monitor', $plugin_version = '', $plugin_name = '' ) {
    if ( ! class_exists( 'CM_API_Client' ) ) {
        return;
    }
    $actor = cm_current_wp_actor();
    if ( '' === $plugin_version && 'compliance-monitor' === $plugin_slug && defined( 'CM_VERSION' ) ) {
        $plugin_version = CM_VERSION;
    }
    $client = new CM_API_Client();
    $client->report_lifecycle_event(
        $event,
        $plugin_slug,
        $plugin_version,
        $actor['login'],
        $actor['email'],
        $plugin_name
    );
}

/**
 * Map a WordPress plugin basename to the audit slug used by Beacon.
 *
 * @param string $basename Plugin file relative to plugins dir.
 * @return string
 */
function cm_plugin_audit_slug( $basename ) {
    $basename = ltrim( str_replace( '\\', '/', (string) $basename ), '/' );
    if ( 0 === strpos( $basename, 'compliance-monitor/' ) ) {
        return 'compliance-monitor';
    }
    if ( 0 === strpos( $basename, 'beacon-checkout/' ) ) {
        return 'beacon-checkout';
    }
    return $basename;
}

/**
 * @param string $basename Plugin basename.
 * @return array{name: string, version: string}
 */
function cm_plugin_file_meta( $basename ) {
    if ( ! function_exists( 'get_plugin_data' ) ) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    $path = WP_PLUGIN_DIR . '/' . ltrim( str_replace( '\\', '/', (string) $basename ), '/' );
    if ( ! is_readable( $path ) ) {
        return array(
            'name'    => (string) $basename,
            'version' => '',
        );
    }
    $data = get_plugin_data( $path, false, false );
    return array(
        'name'    => ! empty( $data['Name'] ) ? (string) $data['Name'] : (string) $basename,
        'version' => ! empty( $data['Version'] ) ? (string) $data['Version'] : '',
    );
}

/**
 * Snapshot of plugins in wp-content/plugins (active and inactive).
 *
 * @return array<int, array{slug: string, name: string, version: string, active: bool}>
 */
function cm_installed_plugins_snapshot() {
    try {
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $all    = get_plugins();
        if ( ! is_array( $all ) ) {
            return array();
        }
        $active = (array) get_option( 'active_plugins', array() );
        $network_active = array();
        if ( is_multisite() ) {
            $network_active = array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) );
        }
        $active_lookup = array_fill_keys( array_merge( $active, $network_active ), true );

        $out = array();
        foreach ( $all as $basename => $data ) {
            if ( count( $out ) >= 200 ) {
                break;
            }
            $slug = cm_plugin_audit_slug( $basename );
            $out[] = array(
                'slug'    => $slug,
                'name'    => ! empty( $data['Name'] ) ? (string) $data['Name'] : $slug,
                'version' => ! empty( $data['Version'] ) ? (string) $data['Version'] : '',
                'active'  => isset( $active_lookup[ $basename ] ),
            );
        }
        return $out;
    } catch ( Throwable $e ) {
        return array();
    }
}

/**
 * Report a lifecycle event for any WordPress plugin (including third-party).
 *
 * @param string $event    installed|activated|deactivated|uninstalled|updated
 * @param string $basename Plugin basename.
 * @return void
 */
function cm_report_wp_plugin_event( $event, $basename ) {
    $basename = (string) $basename;
    if ( '' === $basename ) {
        return;
    }
    $meta = cm_plugin_file_meta( $basename );
    cm_report_lifecycle_event(
        $event,
        cm_plugin_audit_slug( $basename ),
        $meta['version'],
        $meta['name']
    );
}

/**
 * Push the current plugin inventory to Beacon.
 *
 * @return void
 */
function cm_report_plugin_inventory() {
    if ( ! class_exists( 'CM_API_Client' ) ) {
        return;
    }
    $client = new CM_API_Client();
    $client->report_plugin_inventory( cm_installed_plugins_snapshot() );
}

/**
 * Sort findings so the highest-risk items appear first.
 * Secondary sort by category, then title, keeps related items readable within a severity band.
 *
 * @param array $findings Raw findings from a scan payload.
 * @return array
 */
function cm_sort_findings_by_severity( $findings ) {
    if ( ! is_array( $findings ) || empty( $findings ) ) {
        return array();
    }

    $rank = array(
        'CRITICAL' => 0,
        'HIGH'     => 1,
        'MEDIUM'   => 2,
        'LOW'      => 3,
    );

    $sorted = $findings;
    usort(
        $sorted,
        function ( $a, $b ) use ( $rank ) {
            $sa = isset( $a['severity'] ) ? strtoupper( (string) $a['severity'] ) : '';
            $sb = isset( $b['severity'] ) ? strtoupper( (string) $b['severity'] ) : '';
            $ra = isset( $rank[ $sa ] ) ? $rank[ $sa ] : 99;
            $rb = isset( $rank[ $sb ] ) ? $rank[ $sb ] : 99;

            if ( $ra !== $rb ) {
                return $ra - $rb;
            }

            $ca = isset( $a['category'] ) ? (string) $a['category'] : '';
            $cb = isset( $b['category'] ) ? (string) $b['category'] : '';
            $cat = strcasecmp( $ca, $cb );
            if ( 0 !== $cat ) {
                return $cat;
            }

            $ta = isset( $a['title'] ) ? (string) $a['title'] : '';
            $tb = isset( $b['title'] ) ? (string) $b['title'] : '';
            return strcasecmp( $ta, $tb );
        }
    );

    return $sorted;
}

/**
 * Count findings by severity for a compact report summary.
 *
 * @param array $findings Sorted or unsorted findings.
 * @return array<string,int> Keys: CRITICAL, HIGH, MEDIUM, LOW.
 */
function cm_count_findings_by_severity( $findings ) {
    $counts = array(
        'CRITICAL' => 0,
        'HIGH'     => 0,
        'MEDIUM'   => 0,
        'LOW'      => 0,
    );

    if ( ! is_array( $findings ) ) {
        return $counts;
    }

    foreach ( $findings as $finding ) {
        $severity = isset( $finding['severity'] ) ? strtoupper( (string) $finding['severity'] ) : '';
        if ( isset( $counts[ $severity ] ) ) {
            $counts[ $severity ]++;
        }
    }

    return $counts;
}

function cm_render_page_header( $title, $subtitle = '' ) {
    ?>
    <div class="cm-brand-header">
        <img
            src="<?php echo esc_url( cm_brand_logo_url() ); ?>"
            alt="<?php esc_attr_e( 'Testament Technologies', 'compliance-monitor' ); ?>"
            class="cm-brand-logo"
        />
        <div class="cm-brand-heading">
            <h1><?php echo esc_html( $title ); ?></h1>
            <p class="cm-brand-product"><?php esc_html_e( 'Beacon by Testament Technologies', 'compliance-monitor' ); ?></p>
            <?php if ( $subtitle ) : ?>
                <p class="cm-subtitle"><?php echo esc_html( $subtitle ); ?></p>
            <?php endif; ?>
        </div>
    </div>
    <?php
}

function cm_render_admin_notices() {
    if ( ! isset( $_GET['cm_msg'] ) ) {
        return;
    }
    $msg  = sanitize_text_field( wp_unslash( $_GET['cm_msg'] ) );
    $text = isset( $_GET['cm_text'] ) ? urldecode( sanitize_text_field( wp_unslash( $_GET['cm_text'] ) ) ) : '';

    $notices = array(
        'scan_complete'    => array( 'success', __( 'Scan completed successfully.', 'compliance-monitor' ) ),
        'scan_error'       => array( 'error', $text ?: __( 'Scan failed.', 'compliance-monitor' ) ),
        'scan_frequency'   => array( 'warning', $text ?: __( 'Scan frequency limit reached.', 'compliance-monitor' ) ),
        'license_inactive' => array( 'warning', __( 'License is inactive. Please activate your license to run scans.', 'compliance-monitor' ) ),
        'license_invalid'  => array( 'error', __( 'License validation failed. Please check your license key.', 'compliance-monitor' ) ),
    );

    if ( isset( $notices[ $msg ] ) ) {
        printf(
            '<div class="notice notice-%s is-dismissible"><p>%s</p></div>',
            esc_attr( $notices[ $msg ][0] ),
            esc_html( $notices[ $msg ][1] )
        );
    }
}
