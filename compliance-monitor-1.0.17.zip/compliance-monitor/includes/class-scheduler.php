<?php
/**
 * Legacy WP-Cron cleanup.
 *
 * Older versions of the plugin ran merchant-side scheduled scans via WP-Cron.
 * Scans are now initiated and scheduled centrally from the SaaS dashboard, so
 * this class only ensures any previously scheduled event is removed. It no
 * longer runs scans.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CM_Scheduler {

    const CRON_HOOK = 'cm_daily_scan_check';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'init', array( __CLASS__, 'unschedule' ) );
    }

    /**
     * Clear any legacy scheduled scan events left over from older versions.
     */
    public static function unschedule() {
        $timestamp = wp_next_scheduled( self::CRON_HOOK );
        while ( $timestamp ) {
            wp_unschedule_event( $timestamp, self::CRON_HOOK );
            $timestamp = wp_next_scheduled( self::CRON_HOOK );
        }
    }
}
