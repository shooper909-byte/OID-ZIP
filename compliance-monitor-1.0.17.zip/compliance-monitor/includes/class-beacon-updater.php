<?php
/**
 * Private Beacon plugin updater — checks the SaaS API and feeds WordPress Admin updates.
 *
 * Shared by compliance-monitor and beacon-checkout (class_exists guard).
 *
 * @package Beacon
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Beacon_Remote_Updater' ) ) {

	/**
	 * Registers update_plugins / plugins_api hooks for one Beacon plugin package.
	 */
	class Beacon_Remote_Updater {

		/** @var array<string,self> */
		private static $instances = array();

		/** @var string */
		private $slug;

		/** @var string Plugin basename e.g. compliance-monitor/compliance-monitor.php */
		private $plugin_basename;

		/** @var string Installed version */
		private $version;

		/** @var callable():string */
		private $api_base_cb;

		/** @var callable():string */
		private $license_token_cb;

		/** @var callable():string */
		private $license_key_cb;

		/**
		 * @param array{
		 *   slug:string,
		 *   plugin_basename:string,
		 *   version:string,
		 *   api_base:callable,
		 *   license_token:callable,
		 *   license_key:callable
		 * } $config
		 */
		public static function register( array $config ): void {
			$slug = isset( $config['slug'] ) ? (string) $config['slug'] : '';
			if ( '' === $slug || isset( self::$instances[ $slug ] ) ) {
				return;
			}
			self::$instances[ $slug ] = new self( $config );
		}

		/**
		 * @param array<string,mixed> $config Config.
		 */
		private function __construct( array $config ) {
			$this->slug            = (string) $config['slug'];
			$this->plugin_basename = (string) $config['plugin_basename'];
			$this->version         = (string) $config['version'];
			$this->api_base_cb     = $config['api_base'];
			$this->license_token_cb = $config['license_token'];
			$this->license_key_cb  = $config['license_key'];

			add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'inject_update' ) );
			add_filter( 'plugins_api', array( $this, 'plugins_api' ), 10, 3 );
			add_filter( 'http_request_args', array( $this, 'relax_ssl_for_local_api' ), 10, 2 );
		}

		/**
		 * @return string
		 */
		private function api_base(): string {
			$base = call_user_func( $this->api_base_cb );
			return is_string( $base ) ? rtrim( $base, '/' ) : '';
		}

		/**
		 * @return string
		 */
		private function license_token(): string {
			$token = call_user_func( $this->license_token_cb );
			return is_string( $token ) ? $token : '';
		}

		/**
		 * @return string
		 */
		private function license_key(): string {
			$key = call_user_func( $this->license_key_cb );
			return is_string( $key ) ? $key : '';
		}

		/**
		 * Allow localhost API during local plugin development.
		 *
		 * @param array<string,mixed> $args Request args.
		 * @param string              $url  URL.
		 * @return array<string,mixed>
		 */
		public function relax_ssl_for_local_api( $args, $url ) {
			$base = $this->api_base();
			if ( $base && is_string( $url ) && 0 === strpos( $url, $base ) ) {
				if ( false !== strpos( $base, 'localhost' ) || false !== strpos( $base, '127.0.0.1' ) ) {
					$args['sslverify'] = false;
				}
			}
			return $args;
		}

		/**
		 * @param object|null $transient Update transient.
		 * @return object|null
		 */
		public function inject_update( $transient ) {
			if ( ! is_object( $transient ) ) {
				return $transient;
			}

			// WordPress may pass an empty transient during short-circuit; still attach response bucket.
			if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
				$transient->response = array();
			}
			if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
				$transient->no_update = array();
			}

			$payload = $this->fetch_update();
			if ( ! $payload || empty( $payload['update'] ) || empty( $payload['new_version'] ) || empty( $payload['package'] ) ) {
				$transient->no_update[ $this->plugin_basename ] = (object) array(
					'slug'        => $this->slug,
					'plugin'      => $this->plugin_basename,
					'new_version' => $this->version,
					'url'         => isset( $payload['url'] ) ? $payload['url'] : '',
					'package'     => '',
				);
				return $transient;
			}

			$transient->response[ $this->plugin_basename ] = (object) array(
				'slug'           => $this->slug,
				'plugin'         => $this->plugin_basename,
				'new_version'    => (string) $payload['new_version'],
				'url'            => isset( $payload['url'] ) ? (string) $payload['url'] : '',
				'package'        => (string) $payload['package'],
				'tested'         => isset( $payload['tested'] ) ? (string) $payload['tested'] : '',
				'requires'       => isset( $payload['requires'] ) ? (string) $payload['requires'] : '',
				'requires_php'   => isset( $payload['requires_php'] ) ? (string) $payload['requires_php'] : '',
				'icons'          => isset( $payload['icons'] ) && is_array( $payload['icons'] ) ? $payload['icons'] : array(),
				'banners'        => isset( $payload['banners'] ) && is_array( $payload['banners'] ) ? $payload['banners'] : array(),
				'upgrade_notice' => '',
			);

			unset( $transient->no_update[ $this->plugin_basename ] );

			return $transient;
		}

		/**
		 * @param false|object|array $result Result.
		 * @param string             $action Action.
		 * @param object             $args   Args.
		 * @return false|object|array
		 */
		public function plugins_api( $result, $action, $args ) {
			if ( 'plugin_information' !== $action ) {
				return $result;
			}
			if ( ! is_object( $args ) || empty( $args->slug ) || $args->slug !== $this->slug ) {
				return $result;
			}

			$info = $this->fetch_info();
			if ( ! $info ) {
				return $result;
			}

			return (object) array(
				'name'           => isset( $info['name'] ) ? $info['name'] : $this->slug,
				'slug'           => $this->slug,
				'version'        => isset( $info['version'] ) ? $info['version'] : '',
				'author'         => isset( $info['author'] ) ? $info['author'] : 'Testament Technologies',
				'homepage'       => isset( $info['homepage'] ) ? $info['homepage'] : '',
				'requires'       => isset( $info['requires'] ) ? $info['requires'] : '',
				'requires_php'   => isset( $info['requires_php'] ) ? $info['requires_php'] : '',
				'tested'         => isset( $info['tested'] ) ? $info['tested'] : '',
				'download_link'  => isset( $info['download_link'] ) ? $info['download_link'] : '',
				'sections'       => isset( $info['sections'] ) && is_array( $info['sections'] ) ? $info['sections'] : array(),
				'banners'        => isset( $info['banners'] ) && is_array( $info['banners'] ) ? $info['banners'] : array(),
				'last_updated'   => isset( $info['last_updated'] ) ? $info['last_updated'] : '',
			);
		}

		/**
		 * @return array<string,mixed>|null
		 */
		private function fetch_update() {
			$base = $this->api_base();
			if ( '' === $base ) {
				return null;
			}

			$query = array(
				'installed_version' => $this->version,
				'siteUrl'           => home_url( '/' ),
			);
			$key = $this->license_key();
			if ( $key ) {
				$query['licenseKey'] = $key;
			}

			$url = $base . '/api/plugins/' . rawurlencode( $this->slug ) . '/update?' . http_build_query( $query, '', '&' );
			return $this->get_json( $url );
		}

		/**
		 * @return array<string,mixed>|null
		 */
		private function fetch_info() {
			$base = $this->api_base();
			if ( '' === $base ) {
				return null;
			}

			$query = array(
				'siteUrl' => home_url( '/' ),
			);
			$key = $this->license_key();
			if ( $key ) {
				$query['licenseKey'] = $key;
			}

			$url = $base . '/api/plugins/' . rawurlencode( $this->slug ) . '/info?' . http_build_query( $query, '', '&' );
			return $this->get_json( $url );
		}

		/**
		 * @param string $url URL.
		 * @return array<string,mixed>|null
		 */
		private function get_json( $url ) {
			$headers = array(
				'Accept' => 'application/json',
			);
			$token = $this->license_token();
			if ( $token ) {
				$headers['Authorization'] = 'Bearer ' . $token;
			}

			$response = wp_remote_get(
				$url,
				array(
					'timeout' => 15,
					'headers' => $headers,
				)
			);

			if ( is_wp_error( $response ) ) {
				return null;
			}

			$code = wp_remote_retrieve_response_code( $response );
			$body = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( $code < 200 || $code >= 300 || ! is_array( $body ) ) {
				return null;
			}

			return $body;
		}
	}
}
