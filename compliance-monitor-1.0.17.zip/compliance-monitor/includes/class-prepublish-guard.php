<?php
/**
 * Pre-publish compliance guard — warns on findings, blocks CRITICAL publishes.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CM_Prepublish_Guard {

    private static $instance = null;

    /** @var CM_License */
    private $license;

    /** @var CM_API_Client */
    private $api;

    /** @var array<string, array> */
    private $cache = array();

    /** @var bool */
    private $block_product_meta = false;

    /** @var bool */
    private $reverted_live = false;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->license = CM_License::instance();
        $this->api     = new CM_API_Client();

        add_filter( 'wp_insert_post_data', array( $this, 'filter_insert_post_data' ), 20, 2 );
        add_filter( 'rest_pre_insert_product', array( $this, 'filter_rest_pre_insert_post' ), 10, 2 );
        add_filter( 'rest_pre_insert_page', array( $this, 'filter_rest_pre_insert_post' ), 10, 2 );
        add_filter( 'rest_pre_insert_post', array( $this, 'filter_rest_pre_insert_post' ), 10, 2 );
        add_filter( 'woocommerce_rest_pre_insert_product_object', array( $this, 'filter_rest_pre_insert_product_object' ), 10, 3 );
        add_action( 'woocommerce_admin_process_product_object', array( $this, 'maybe_restore_product_meta' ), 1 );
        add_action( 'admin_notices', array( $this, 'render_admin_notices' ) );
    }

    /**
     * Classic editor / wp-admin form posts. REST saves are handled by rest_pre_insert_* .
     *
     * @param array $data
     * @param array $postarr
     * @return array
     */
    public function filter_insert_post_data( $data, $postarr ) {
        if ( $this->should_skip_environment() ) {
            return $data;
        }
        if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
            return $data;
        }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return $data;
        }
        $post_id_hint = ! empty( $postarr['ID'] ) ? (int) $postarr['ID'] : 0;
        if ( $post_id_hint && ( wp_is_post_revision( $post_id_hint ) || wp_is_post_autosave( $post_id_hint ) ) ) {
            return $data;
        }

        $post_type = isset( $data['post_type'] ) ? $data['post_type'] : '';
        if ( ! $this->is_watched_type( $post_type ) ) {
            return $data;
        }

        $new_status = isset( $data['post_status'] ) ? $data['post_status'] : '';
        $post_id    = $post_id_hint;
        if ( ! $this->should_check_status( $new_status, $post_id ) ) {
            return $data;
        }

        $payload = $this->payload_from_post_data( $data, $postarr, $post_type );
        $result  = $this->run_check( $payload );

        if ( ! empty( $result['blocked'] ) ) {
            $this->store_notice( 'blocked', $result['findings'] );
            $reverted = $this->prevent_classic_publish( $data, $postarr );
            $this->block_product_meta = ( 'product' === $post_type && $this->reverted_live );
            return $reverted;
        }

        if ( ! empty( $result['check_failed'] ) ) {
            $this->store_notice( 'check_failed', array(), $result['error'] );
            return $data;
        }

        if ( ! empty( $result['findings'] ) ) {
            $this->store_notice( 'warning', $result['findings'] );
        }

        return $data;
    }

    /**
     * Gutenberg / WP REST for product, page, and post.
     *
     * @param WP_Post|stdClass|WP_Error $prepared
     * @param WP_REST_Request           $request
     * @return WP_Post|stdClass|WP_Error
     */
    public function filter_rest_pre_insert_post( $prepared, $request ) {
        if ( is_wp_error( $prepared ) ) {
            return $prepared;
        }
        if ( $this->should_skip_environment() ) {
            return $prepared;
        }

        $post_type = $this->prepared_post_type( $prepared, $request );
        if ( ! $this->is_watched_type( $post_type ) ) {
            return $prepared;
        }

        $post_id    = $this->prepared_post_id( $prepared, $request );
        $new_status = $this->prepared_post_status( $prepared, $request, $post_id );
        if ( ! $this->should_check_status( $new_status, $post_id ) ) {
            return $prepared;
        }

        $payload = $this->payload_from_rest_post( $prepared, $request, $post_type, $post_id );
        $result  = $this->run_check( $payload );

        if ( ! empty( $result['blocked'] ) ) {
            $this->store_notice( 'blocked', $result['findings'] );
            return $this->blocked_wp_error( $result['findings'] );
        }

        if ( ! empty( $result['check_failed'] ) ) {
            $this->store_notice( 'check_failed', array(), $result['error'] );
            return $prepared;
        }

        if ( ! empty( $result['findings'] ) ) {
            $this->store_notice( 'warning', $result['findings'] );
        }

        return $prepared;
    }

    /**
     * WooCommerce REST / new product editor.
     *
     * @param WC_Product      $product
     * @param WP_REST_Request $request
     * @param bool            $creating
     * @return WC_Product|WP_Error
     */
    public function filter_rest_pre_insert_product_object( $product, $request, $creating ) {
        if ( is_wp_error( $product ) ) {
            return $product;
        }
        if ( $this->should_skip_environment() ) {
            return $product;
        }

        $post_id    = $product->get_id();
        $new_status = $product->get_status();
        if ( ! $new_status && $request instanceof WP_REST_Request ) {
            $new_status = (string) $request->get_param( 'status' );
        }
        if ( ! $this->should_check_status( $new_status ? $new_status : 'draft', $creating ? 0 : $post_id ) ) {
            return $product;
        }

        $payload = array(
            'type'             => 'product',
            'id'               => $post_id ? $post_id : 'preview',
            'title'            => $product->get_name(),
            'description'      => wp_strip_all_tags( (string) $product->get_description() ),
            'shortDescription' => wp_strip_all_tags( (string) $product->get_short_description() ),
            'sku'              => (string) $product->get_sku(),
            'categories'       => $this->term_names_from_ids( $product->get_category_ids(), 'product_cat' ),
            'tags'             => $this->term_names_from_ids( $product->get_tag_ids(), 'product_tag' ),
            'attributes'       => $this->product_attribute_strings( $product ),
        );

        $result = $this->run_check( $payload );

        if ( ! empty( $result['blocked'] ) ) {
            $this->store_notice( 'blocked', $result['findings'] );
            return $this->blocked_wp_error( $result['findings'] );
        }

        if ( ! empty( $result['check_failed'] ) ) {
            $this->store_notice( 'check_failed', array(), $result['error'] );
            return $product;
        }

        if ( ! empty( $result['findings'] ) ) {
            $this->store_notice( 'warning', $result['findings'] );
        }

        return $product;
    }

    /**
     * If a classic product publish was blocked, keep SKU/meta from overwriting live values.
     *
     * @param WC_Product $product
     */
    public function maybe_restore_product_meta( $product ) {
        if ( ! $this->block_product_meta || ! $product || ! $product->get_id() ) {
            return;
        }

        $sku = get_post_meta( $product->get_id(), '_sku', true );
        try {
            $product->set_sku( is_string( $sku ) ? $sku : '' );
        } catch ( Exception $e ) {
            // Do not fail the product save if SKU restore is rejected.
        }
    }

    public function render_admin_notices() {
        $user_id = get_current_user_id();
        if ( ! $user_id ) {
            return;
        }

        $notice = get_transient( $this->notice_key( $user_id ) );
        if ( ! is_array( $notice ) || empty( $notice['kind'] ) ) {
            return;
        }

        delete_transient( $this->notice_key( $user_id ) );

        $kind     = $notice['kind'];
        $findings = isset( $notice['findings'] ) && is_array( $notice['findings'] ) ? $notice['findings'] : array();
        $class    = 'blocked' === $kind ? 'notice-error' : ( 'check_failed' === $kind ? 'notice-warning' : 'notice-warning' );

        echo '<div class="notice ' . esc_attr( $class ) . ' is-dismissible"><p><strong>';
        if ( 'blocked' === $kind ) {
            esc_html_e( 'Beacon blocked this publish because of CRITICAL compliance findings.', 'compliance-monitor' );
        } elseif ( 'check_failed' === $kind ) {
            esc_html_e( 'Beacon could not run a live compliance check. The change was saved.', 'compliance-monitor' );
        } else {
            esc_html_e( 'Beacon found possible compliance issues. The change was saved — review before leaving this live.', 'compliance-monitor' );
        }
        echo '</strong></p>';

        if ( 'check_failed' === $kind && ! empty( $notice['error'] ) ) {
            echo '<p>' . esc_html( (string) $notice['error'] ) . '</p>';
        }

        if ( $findings ) {
            echo '<ul style="list-style:disc;margin-left:1.5em;">';
            foreach ( $findings as $finding ) {
                if ( ! is_array( $finding ) ) {
                    continue;
                }
                $title = isset( $finding['title'] ) ? (string) $finding['title'] : '';
                $sev   = isset( $finding['severity'] ) ? (string) $finding['severity'] : '';
                $rec   = isset( $finding['recommendation'] ) ? (string) $finding['recommendation'] : '';
                $repl  = isset( $finding['suggestedReplacementText'] ) ? (string) $finding['suggestedReplacementText'] : '';
                if ( '' === $title ) {
                    continue;
                }
                echo '<li><strong>' . esc_html( $title ) . '</strong>';
                if ( $sev ) {
                    echo ' (' . esc_html( $sev ) . ')';
                }
                if ( $rec ) {
                    echo ' — ' . esc_html( $rec );
                }
                if ( $repl ) {
                    echo '<br><em>' . esc_html( sprintf( __( 'Suggested: %s', 'compliance-monitor' ), $repl ) ) . '</em>';
                }
                echo '</li>';
            }
            echo '</ul>';
        }

        echo '</div>';
    }

    private function run_check( $payload ) {
        $key = md5( (string) wp_json_encode( $payload ) );
        if ( isset( $this->cache[ $key ] ) ) {
            return $this->cache[ $key ];
        }

        if ( ! $this->license->is_active() || ! $this->license->get_token() ) {
            $result = array(
                'blocked'      => false,
                'findings'     => array(),
                'check_failed' => false,
            );
            $this->cache[ $key ] = $result;
            return $result;
        }

        $token = $this->license->get_token();

        $response = $this->api->check_content( $token, $payload );
        if ( empty( $response['success'] ) || ! is_array( $response['data'] ) ) {
            $result = array(
                'blocked'      => false,
                'findings'     => array(),
                'check_failed' => true,
                'error'        => isset( $response['error'] ) ? (string) $response['error'] : __( 'The Beacon API did not respond in time.', 'compliance-monitor' ),
            );
            $this->cache[ $key ] = $result;
            return $result;
        }

        $data     = $response['data'];
        $findings = isset( $data['findings'] ) && is_array( $data['findings'] ) ? $data['findings'] : array();
        $blocked  = ! empty( $data['blocked'] );

        $result = array(
            'blocked'      => $blocked,
            'findings'     => $findings,
            'check_failed' => false,
        );
        $this->cache[ $key ] = $result;
        return $result;
    }

    private function should_skip_environment() {
        if ( defined( 'WP_IMPORTING' ) && WP_IMPORTING ) {
            return true;
        }
        if ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) {
            return true;
        }
        if ( defined( 'WP_CLI' ) && WP_CLI ) {
            return true;
        }
        if ( ! empty( $_REQUEST['bulk_edit'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            return true;
        }
        if ( isset( $_REQUEST['action'] ) && 'woocommerce_do_ajax_product_import' === $_REQUEST['action'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            return true;
        }
        if ( ! is_admin() && ! ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
            return true;
        }
        return false;
    }

    private function is_watched_type( $post_type ) {
        return in_array( $post_type, array( 'product', 'page', 'post' ), true );
    }

    private function should_check_status( $new_status, $post_id ) {
        if ( in_array( $new_status, array( 'trash', 'auto-draft', 'inherit' ), true ) ) {
            return false;
        }

        $going_live = in_array( $new_status, array( 'publish', 'future' ), true );
        $already_live = false;
        if ( $post_id ) {
            $current = get_post_status( $post_id );
            $already_live = in_array( $current, array( 'publish', 'future' ), true );
        }

        return $going_live || $already_live;
    }

    private function payload_from_post_data( $data, $postarr, $post_type ) {
        $post_id = ! empty( $postarr['ID'] ) ? (int) $postarr['ID'] : 0;
        $type    = 'product' === $post_type ? 'product' : ( 'page' === $post_type ? 'page' : 'post' );
        $payload = array(
            'type'        => $type,
            'id'          => $post_id ? $post_id : 'preview',
            'title'       => isset( $data['post_title'] ) ? wp_strip_all_tags( (string) $data['post_title'] ) : '',
            'description' => isset( $data['post_content'] ) ? wp_strip_all_tags( (string) $data['post_content'] ) : '',
        );

        if ( 'product' === $post_type ) {
            $payload['shortDescription'] = isset( $data['post_excerpt'] ) ? wp_strip_all_tags( (string) $data['post_excerpt'] ) : '';
            $payload['sku']              = isset( $_POST['_sku'] ) ? sanitize_text_field( wp_unslash( $_POST['_sku'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $payload['categories']       = $this->term_names_from_request( 'product_cat' );
            $payload['tags']             = $this->term_names_from_request( 'product_tag' );
        }

        return $payload;
    }

    private function payload_from_rest_post( $prepared, $request, $post_type, $post_id ) {
        $type  = 'product' === $post_type ? 'product' : ( 'page' === $post_type ? 'page' : 'post' );
        $title = $this->rest_rendered_text( isset( $prepared->post_title ) ? $prepared->post_title : $request->get_param( 'title' ) );
        $body  = $this->rest_rendered_text( isset( $prepared->post_content ) ? $prepared->post_content : $request->get_param( 'content' ) );

        $payload = array(
            'type'        => $type,
            'id'          => $post_id ? $post_id : 'preview',
            'title'       => wp_strip_all_tags( $title ),
            'description' => wp_strip_all_tags( $body ),
        );

        if ( 'product' === $post_type ) {
            $excerpt = $this->rest_rendered_text( isset( $prepared->post_excerpt ) ? $prepared->post_excerpt : $request->get_param( 'excerpt' ) );
            $payload['shortDescription'] = wp_strip_all_tags( $excerpt );
            $sku = $request->get_param( 'sku' );
            if ( is_string( $sku ) ) {
                $payload['sku'] = $sku;
            } elseif ( $post_id && function_exists( 'wc_get_product' ) ) {
                $product = wc_get_product( $post_id );
                if ( $product ) {
                    $payload['sku'] = (string) $product->get_sku();
                }
            }
        }

        return $payload;
    }

    private function rest_rendered_text( $value ) {
        if ( is_string( $value ) ) {
            return $value;
        }
        if ( is_array( $value ) ) {
            if ( isset( $value['raw'] ) && is_string( $value['raw'] ) ) {
                return $value['raw'];
            }
            if ( isset( $value['rendered'] ) && is_string( $value['rendered'] ) ) {
                return $value['rendered'];
            }
        }
        if ( is_object( $value ) ) {
            if ( isset( $value->raw ) && is_string( $value->raw ) ) {
                return $value->raw;
            }
            if ( isset( $value->rendered ) && is_string( $value->rendered ) ) {
                return $value->rendered;
            }
        }
        return '';
    }

    private function prepared_post_type( $prepared, $request ) {
        if ( isset( $prepared->post_type ) && $prepared->post_type ) {
            return $prepared->post_type;
        }
        $route = $request instanceof WP_REST_Request ? $request->get_route() : '';
        if ( false !== strpos( (string) $route, '/product' ) ) {
            return 'product';
        }
        if ( false !== strpos( (string) $route, '/pages' ) ) {
            return 'page';
        }
        return 'post';
    }

    private function prepared_post_id( $prepared, $request ) {
        if ( isset( $prepared->ID ) && $prepared->ID ) {
            return (int) $prepared->ID;
        }
        if ( $request instanceof WP_REST_Request ) {
            $id = $request->get_param( 'id' );
            if ( $id ) {
                return (int) $id;
            }
        }
        return 0;
    }

    private function prepared_post_status( $prepared, $request, $post_id ) {
        if ( isset( $prepared->post_status ) && $prepared->post_status ) {
            return $prepared->post_status;
        }
        if ( $request instanceof WP_REST_Request ) {
            $status = $request->get_param( 'status' );
            if ( is_string( $status ) && $status ) {
                return $status;
            }
        }
        if ( $post_id ) {
            return (string) get_post_status( $post_id );
        }
        return 'draft';
    }

    private function prevent_classic_publish( $data, $postarr ) {
        $this->reverted_live = false;
        $post_id = ! empty( $postarr['ID'] ) ? (int) $postarr['ID'] : 0;
        if ( $post_id ) {
            $existing = get_post( $post_id );
            if ( $existing ) {
                $already_live = in_array( $existing->post_status, array( 'publish', 'future' ), true );
                if ( $already_live ) {
                    $data['post_title']   = $existing->post_title;
                    $data['post_content'] = $existing->post_content;
                    $data['post_excerpt'] = $existing->post_excerpt;
                    $data['post_status']  = $existing->post_status;
                    $data['post_name']    = $existing->post_name;
                    $this->reverted_live  = true;
                    return $data;
                }
            }
        }

        $data['post_status'] = 'draft';
        return $data;
    }

    private function blocked_wp_error( $findings ) {
        $critical = array();
        foreach ( $findings as $finding ) {
            if ( is_array( $finding ) && isset( $finding['severity'] ) && 'CRITICAL' === $finding['severity'] ) {
                $critical[] = $finding;
            }
        }
        $lines = array(
            __( 'Beacon blocked this publish because of CRITICAL compliance findings:', 'compliance-monitor' ),
        );
        foreach ( $critical as $finding ) {
            $line = isset( $finding['title'] ) ? (string) $finding['title'] : '';
            if ( ! empty( $finding['recommendation'] ) ) {
                $line .= ' — ' . $finding['recommendation'];
            }
            if ( $line ) {
                $lines[] = $line;
            }
        }

        return new WP_Error(
            'cm_compliance_blocked',
            implode( "\n", $lines ),
            array(
                'status'   => 400,
                'findings' => $critical,
            )
        );
    }

    private function term_names_from_request( $taxonomy ) {
        if ( empty( $_POST['tax_input'][ $taxonomy ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
            return array();
        }
        $raw = wp_unslash( $_POST['tax_input'][ $taxonomy ] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        if ( is_string( $raw ) ) {
            return array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( ',', $raw ) ) ) ) );
        }
        if ( ! is_array( $raw ) ) {
            return array();
        }
        $names = array();
        foreach ( $raw as $item ) {
            if ( is_numeric( $item ) ) {
                $term = get_term( (int) $item, $taxonomy );
                if ( $term && ! is_wp_error( $term ) ) {
                    $names[] = $term->name;
                }
            } else {
                $names[] = sanitize_text_field( (string) $item );
            }
        }
        return array_values( array_filter( $names ) );
    }

    private function term_names_from_ids( $ids, $taxonomy ) {
        if ( ! is_array( $ids ) ) {
            return array();
        }
        $names = array();
        foreach ( $ids as $id ) {
            $term = get_term( (int) $id, $taxonomy );
            if ( $term && ! is_wp_error( $term ) ) {
                $names[] = $term->name;
            }
        }
        return $names;
    }

    private function product_attribute_strings( $product ) {
        if ( ! $product || ! method_exists( $product, 'get_attributes' ) ) {
            return array();
        }
        $out = array();
        foreach ( $product->get_attributes() as $attribute ) {
            $name = is_object( $attribute ) && method_exists( $attribute, 'get_name' ) ? $attribute->get_name() : '';
            $opts = is_object( $attribute ) && method_exists( $attribute, 'get_options' ) ? $attribute->get_options() : array();
            if ( ! is_array( $opts ) ) {
                continue;
            }
            $labels = array();
            foreach ( $opts as $opt ) {
                if ( is_numeric( $opt ) ) {
                    $term = get_term( (int) $opt );
                    $labels[] = ( $term && ! is_wp_error( $term ) ) ? $term->name : (string) $opt;
                } else {
                    $labels[] = (string) $opt;
                }
            }
            if ( $name || $labels ) {
                $out[] = trim( $name . ': ' . implode( ', ', $labels ) );
            }
        }
        return $out;
    }

    private function store_notice( $kind, $findings, $error = '' ) {
        $user_id = get_current_user_id();
        if ( ! $user_id ) {
            return;
        }
        set_transient(
            $this->notice_key( $user_id ),
            array(
                'kind'     => $kind,
                'findings' => $findings,
                'error'    => $error,
            ),
            120
        );
    }

    private function notice_key( $user_id ) {
        return 'cm_prepublish_notice_' . (int) $user_id;
    }
}
