<?php
/**
 * Outbound collect worker — fulfills SaaS scans that could not pull /collect
 * (parked DNS, WAF, inbound firewall). The plugin never creates scans; it only
 * uploads payloads for jobs the dashboard/scheduler opened.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CM_Collect_Worker {

    const CRON_HOOK     = 'cm_poll_pending_collect';
    const CRON_INTERVAL = 'cm_every_minute';
    const LOCK_PREFIX   = 'cm_collect_lock_';
    const LOCK_TTL      = 300;
    const ADMIN_THROTTLE = 'cm_collect_admin_tick';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_filter( 'cron_schedules', array( $this, 'add_cron_schedule' ) );
        add_action( 'init', array( $this, 'ensure_schedule' ) );
        add_action( self::CRON_HOOK, array( $this, 'run' ) );
        add_action( 'admin_init', array( $this, 'maybe_run_on_admin' ) );
    }

    public function add_cron_schedule( $schedules ) {
        if ( ! isset( $schedules[ self::CRON_INTERVAL ] ) ) {
            $schedules[ self::CRON_INTERVAL ] = array(
                'interval' => 60,
                'display'  => __( 'Every minute (Beacon collect)', 'compliance-monitor' ),
            );
        }
        return $schedules;
    }

    public function ensure_schedule() {
        $license = CM_License::instance();
        if ( ! $license->is_active() ) {
            self::unschedule();
            return;
        }

        if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
            wp_schedule_event( time() + 30, self::CRON_INTERVAL, self::CRON_HOOK );
        }
    }

    public static function unschedule() {
        $timestamp = wp_next_scheduled( self::CRON_HOOK );
        while ( $timestamp ) {
            wp_unschedule_event( $timestamp, self::CRON_HOOK );
            $timestamp = wp_next_scheduled( self::CRON_HOOK );
        }
    }

    /**
     * Faster pickup when an operator is in wp-admin (throttled to ~45s).
     */
    public function maybe_run_on_admin() {
        if ( get_transient( self::ADMIN_THROTTLE ) ) {
            return;
        }
        set_transient( self::ADMIN_THROTTLE, 1, 45 );
        $this->run();
    }

    public function run() {
        $license = CM_License::instance();
        if ( ! $license->is_active() ) {
            return;
        }

        $token = $license->get_token();
        if ( empty( $token ) ) {
            if ( ! $license->revalidate() ) {
                return;
            }
            $token = $license->get_token();
            if ( empty( $token ) ) {
                return;
            }
        }

        $api      = new CM_API_Client();
        $response = $api->get_pending_collect( $token );

        if ( ! $response['success'] ) {
            // Stale JWT — refresh once and retry.
            if ( ! empty( $response['code'] ) && 401 === (int) $response['code'] ) {
                if ( $license->revalidate() ) {
                    $token    = $license->get_token();
                    $response = $api->get_pending_collect( $token );
                }
            }
        }

        if ( ! $response['success'] || empty( $response['data'] ) || empty( $response['data']['scanId'] ) ) {
            return;
        }

        $scan_id = sanitize_text_field( (string) $response['data']['scanId'] );
        $lean    = ! empty( $response['data']['lean'] );

        $lock_key = self::LOCK_PREFIX . $scan_id;
        if ( get_transient( $lock_key ) ) {
            return;
        }
        set_transient( $lock_key, 1, self::LOCK_TTL );

        try {
            $this->fulfill( $api, $token, $scan_id, $lean );
        } finally {
            delete_transient( $lock_key );
        }
    }

    private function fulfill( CM_API_Client $api, $token, $scan_id, $lean ) {
        if ( $lean ) {
            add_filter( 'cm_render_fetch_enabled', '__return_false', 100 );
            add_filter(
                'cm_render_fetch_max',
                static function () {
                    return 0;
                },
                100
            );
            add_filter(
                'cm_render_fetch_time_budget',
                static function () {
                    return 5;
                },
                100
            );
        } else {
            add_filter(
                'cm_render_fetch_max',
                static function ( $max ) {
                    $max = (int) $max;
                    return $max > 0 ? min( $max, 80 ) : 80;
                },
                5
            );
            add_filter(
                'cm_render_fetch_time_budget',
                static function ( $seconds ) {
                    $seconds = (int) $seconds;
                    return $seconds > 0 ? min( $seconds, 25 ) : 25;
                },
                5
            );
        }

        if ( function_exists( 'ignore_user_abort' ) ) {
            ignore_user_abort( true );
        }
        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 300 );
        }

        $collector = new CM_Data_Collector();
        $payload   = $collector->collect();

        $submit = $api->submit_collect_payload( $scan_id, $payload, $token );
        if ( ! $submit['success'] && ! empty( $submit['code'] ) && 401 === (int) $submit['code'] ) {
            $license = CM_License::instance();
            if ( $license->revalidate() ) {
                $token  = $license->get_token();
                $submit = $api->submit_collect_payload( $scan_id, $payload, $token );
            }
        }

        if ( ! $submit['success'] ) {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                error_log( 'Beacon collect upload failed: ' . ( isset( $submit['error'] ) ? $submit['error'] : 'unknown' ) );
            }
        }
    }
}
