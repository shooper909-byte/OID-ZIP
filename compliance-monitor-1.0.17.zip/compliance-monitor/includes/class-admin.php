<?php
/**
 * Admin UI — license screen, scan controls, results display.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CM_Admin {

    private static $instance = null;
    private $license;
    private $api;
    private $collector;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->license   = CM_License::instance();
        $this->api       = new CM_API_Client();
        $this->collector = new CM_Data_Collector();

        add_action( 'admin_menu', array( $this, 'register_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_action( 'admin_post_cm_activate_license', array( $this, 'handle_activate_license' ) );
        add_action( 'admin_post_cm_deactivate_license', array( $this, 'handle_deactivate_license' ) );
        add_action( 'admin_post_cm_save_settings', array( $this, 'handle_save_settings' ) );
    }

    public function register_menu() {
        add_menu_page(
            __( 'Beacon', 'compliance-monitor' ),
            __( 'Beacon', 'compliance-monitor' ),
            'manage_woocommerce',
            'compliance-monitor',
            array( $this, 'render_dashboard' ),
            cm_menu_icon_url(),
            58
        );
        add_submenu_page(
            'compliance-monitor',
            __( 'Dashboard', 'compliance-monitor' ),
            __( 'Dashboard', 'compliance-monitor' ),
            'manage_woocommerce',
            'compliance-monitor',
            array( $this, 'render_dashboard' )
        );

        add_submenu_page(
            'compliance-monitor',
            __( 'License', 'compliance-monitor' ),
            __( 'License', 'compliance-monitor' ),
            'manage_woocommerce',
            'compliance-monitor-license',
            array( $this, 'render_license' )
        );

        add_submenu_page(
            'compliance-monitor',
            __( 'Latest Report', 'compliance-monitor' ),
            __( 'Latest Report', 'compliance-monitor' ),
            'manage_woocommerce',
            'compliance-monitor-report',
            array( $this, 'render_report' )
        );
    }

    public function enqueue_assets( $hook ) {
        // Menu icon CSS must load on every admin screen — WP does not size
        // custom <img> menu icons, so a full-size PNG will overflow the sidebar.
        wp_register_style( 'cm-admin-menu', false, array(), CM_VERSION );
        wp_enqueue_style( 'cm-admin-menu' );
        wp_add_inline_style(
            'cm-admin-menu',
            '#toplevel_page_compliance-monitor .wp-menu-image img{width:20px;height:20px;padding:7px 0 0;opacity:.6;object-fit:contain;}' .
            '#toplevel_page_compliance-monitor:hover .wp-menu-image img,' .
            '#toplevel_page_compliance-monitor.wp-has-current-submenu .wp-menu-image img,' .
            '#toplevel_page_compliance-monitor.current .wp-menu-image img{opacity:1;}'
        );

        if ( strpos( $hook, 'compliance-monitor' ) === false ) {
            return;
        }
        wp_enqueue_style(
            'cm-admin',
            CM_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            CM_VERSION
        );
    }

    public function handle_activate_license() {
        check_admin_referer( 'cm_activate_license' );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'Unauthorized.', 'compliance-monitor' ) );
        }

        $key = isset( $_POST['cm_license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['cm_license_key'] ) ) : '';
        $result = $this->license->activate( $key );

        $redirect = add_query_arg( array(
            'page'    => 'compliance-monitor-license',
            'cm_msg'  => $result['success'] ? 'activated' : 'error',
            'cm_text' => urlencode( $result['message'] ),
        ), admin_url( 'admin.php' ) );

        wp_safe_redirect( $redirect );
        exit;
    }

    public function handle_save_settings() {
        check_admin_referer( 'cm_save_settings' );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'Unauthorized.', 'compliance-monitor' ) );
        }

        // A wp-config.php constant takes precedence; don't let the admin field
        // silently do nothing in that case.
        if ( cm_api_base_url_is_locked() ) {
            $text = __( 'API URL is locked by wp-config.php and cannot be changed here.', 'compliance-monitor' );
        } else {
            $url = isset( $_POST['cm_api_base_url'] ) ? esc_url_raw( wp_unslash( $_POST['cm_api_base_url'] ) ) : '';
            $url = rtrim( trim( $url ), '/' );

            if ( $url ) {
                update_option( 'cm_api_base_url', $url );
                $text = __( 'API URL saved.', 'compliance-monitor' );
            } else {
                delete_option( 'cm_api_base_url' );
                $text = __( 'API URL cleared.', 'compliance-monitor' );
            }
        }

        $redirect = add_query_arg( array(
            'page'    => 'compliance-monitor-license',
            'cm_msg'  => 'settings_saved',
            'cm_text' => urlencode( $text ),
        ), admin_url( 'admin.php' ) );

        wp_safe_redirect( $redirect );
        exit;
    }

    public function handle_deactivate_license() {
        check_admin_referer( 'cm_deactivate_license' );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'Unauthorized.', 'compliance-monitor' ) );
        }

        $this->license->deactivate();

        wp_safe_redirect( add_query_arg( array(
            'page'   => 'compliance-monitor-license',
            'cm_msg' => 'deactivated',
        ), admin_url( 'admin.php' ) ) );
        exit;
    }

    public function render_dashboard() {
        $this->sync_latest_scan();
        $scan_result = $this->get_last_scan();
        $last_scan_date = $this->get_formatted_last_scan_date( $scan_result );
        include CM_PLUGIN_DIR . 'admin/views/dashboard.php';
    }

    public function render_license() {
        include CM_PLUGIN_DIR . 'admin/views/license.php';
    }

    public function render_report() {
        $this->sync_latest_scan();
        $scan_result = $this->get_last_scan();
        $last_scan_date = $this->get_formatted_last_scan_date( $scan_result );
        include CM_PLUGIN_DIR . 'admin/views/report.php';
    }

    /**
     * Pull the most recent completed scan from the SaaS platform so the merchant
     * can review it. Scans are initiated and scheduled centrally by the
     * compliance team from the SaaS dashboard — this plugin only displays the
     * results, it never starts scans itself.
     */
    private function sync_latest_scan() {
        if ( ! $this->license->is_active() ) {
            return;
        }

        $token = $this->license->get_token();
        if ( empty( $token ) && ! $this->license->revalidate() ) {
            return;
        }

        $token = $this->license->get_token();
        if ( empty( $token ) ) {
            return;
        }

        $response = $this->api->get_latest_scan( $token );

        // 404 simply means no scan has been run for this site yet.
        if ( empty( $response['success'] ) || empty( $response['data']['id'] ) ) {
            return;
        }

        $scan = $response['data'];
        update_option( 'cm_last_scan_id', $scan['id'] );
        update_option( 'cm_last_scan_result', wp_json_encode( $scan ) );

        $completed_at = ! empty( $scan['completedAt'] ) ? $scan['completedAt'] : ( ! empty( $scan['scannedAt'] ) ? $scan['scannedAt'] : '' );
        if ( $completed_at ) {
            update_option( 'cm_last_scan_completed_at', $completed_at );
            update_option( 'cm_last_scan_date', $this->format_scan_datetime( $completed_at ) );
        }
    }

    /**
     * ISO timestamp (UTC) for the most recent scan, if known.
     *
     * @param array|null $scan_result Decoded scan payload from the API.
     */
    public function get_scan_completed_iso( $scan_result = null ) {
        if ( is_array( $scan_result ) ) {
            if ( ! empty( $scan_result['completedAt'] ) ) {
                return $scan_result['completedAt'];
            }
            if ( ! empty( $scan_result['scannedAt'] ) ) {
                return $scan_result['scannedAt'];
            }
        }

        return get_option( 'cm_last_scan_completed_at', '' );
    }

    /**
     * Format an API scan timestamp in the WordPress site timezone with abbreviation (e.g. CDT).
     *
     * @param string $iso_string UTC ISO-8601 timestamp from the SaaS API.
     */
    public function format_scan_datetime( $iso_string ) {
        if ( empty( $iso_string ) ) {
            return '';
        }

        $timestamp = strtotime( $iso_string );
        if ( false === $timestamp ) {
            return '';
        }

        $format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) . ' T';

        if ( function_exists( 'wp_date' ) ) {
            return wp_date( $format, $timestamp );
        }

        return get_date_from_gmt( gmdate( 'Y-m-d H:i:s', $timestamp ), $format );
    }

    /**
     * Human-readable last scan time for dashboard/report views.
     *
     * @param array|null $scan_result Decoded scan payload from the API.
     */
    public function get_formatted_last_scan_date( $scan_result = null ) {
        return $this->format_scan_datetime( $this->get_scan_completed_iso( $scan_result ) );
    }

    private function get_last_scan() {
        $json = get_option( 'cm_last_scan_result', '' );
        if ( empty( $json ) ) {
            return null;
        }
        return json_decode( $json, true );
    }

    public function get_severity_class( $severity ) {
        $map = array(
            'CRITICAL' => 'cm-severity-critical',
            'HIGH'     => 'cm-severity-high',
            'MEDIUM'   => 'cm-severity-medium',
            'LOW'      => 'cm-severity-low',
        );
        return isset( $map[ $severity ] ) ? $map[ $severity ] : '';
    }
}
