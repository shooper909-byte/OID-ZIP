<?php
/**
 * SaaS API client — thin transport layer, no compliance logic.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CM_API_Client {

    private $base_url;

    public function __construct() {
        $this->base_url = cm_get_api_base_url();
    }

    /**
     * Validate license key with SaaS backend.
     */
    public function validate_license( $license_key, $site_url ) {
        $actor = function_exists( 'cm_current_wp_actor' ) ? cm_current_wp_actor() : array(
            'login' => '',
            'email' => '',
        );
        return $this->post( '/api/license/validate', array(
            'licenseKey'    => $license_key,
            'siteUrl'       => $site_url,
            'pluginSlug'    => 'compliance-monitor',
            'pluginVersion' => defined( 'CM_VERSION' ) ? CM_VERSION : '',
            'actorLogin'    => $actor['login'],
            'actorEmail'    => $actor['email'],
            'plugins'       => function_exists( 'cm_installed_plugins_snapshot' )
                ? cm_installed_plugins_snapshot()
                : array(),
        ) );
    }

    /**
     * Report plugin/license lifecycle for SaaS audit logs.
     *
     * @param string $event installed|activated|deactivated|uninstalled|updated|license_deactivated
     * @return array
     */
    public function report_lifecycle_event( $event, $plugin_slug, $plugin_version = '', $actor_login = '', $actor_email = '', $plugin_name = '' ) {
        $token = (string) get_option( 'cm_license_token', '' );
        $key   = (string) get_option( 'cm_license_key', '' );
        if ( '' === $token && '' === $key ) {
            return array(
                'success' => false,
                'error'   => 'No license credentials.',
            );
        }

        $body = array(
            'event'         => $event,
            'pluginSlug'    => $plugin_slug,
            'pluginName'    => $plugin_name,
            'pluginVersion' => $plugin_version,
            'siteUrl'       => home_url(),
            'licenseKey'    => $key,
            'actorLogin'    => $actor_login,
            'actorEmail'    => $actor_email,
        );

        return $this->post( '/api/plugins/lifecycle', $body, $token ? $token : null, 3 );
    }

    /**
     * Report the full installed plugin list.
     *
     * @param array $plugins Snapshot rows.
     * @return array
     */
    public function report_plugin_inventory( $plugins ) {
        $token = (string) get_option( 'cm_license_token', '' );
        $key   = (string) get_option( 'cm_license_key', '' );
        if ( '' === $token && '' === $key ) {
            return array(
                'success' => false,
                'error'   => 'No license credentials.',
            );
        }

        return $this->post(
            '/api/plugins/inventory',
            array(
                'plugins'    => is_array( $plugins ) ? $plugins : array(),
                'siteUrl'    => home_url(),
                'licenseKey' => $key,
            ),
            $token ? $token : null,
            3
        );
    }

    /**
     * Fetch the most recent completed scan for this site. Scans are initiated
     * and scheduled centrally from the SaaS dashboard; the plugin only reads the
     * results for display.
     */
    public function get_latest_scan( $token ) {
        return $this->get( '/api/scans/latest', $token );
    }

    /**
     * Poll for a scan waiting for this site to upload a collect payload.
     * Returns success with data, or success=false with code 204 when nothing pending.
     */
    public function get_pending_collect( $token ) {
        return $this->get( '/api/scans/pending-collect', $token, 30, true );
    }

    /**
     * Upload a locally collected scan payload for a waiting SaaS scan.
     */
    public function submit_collect_payload( $scan_id, $payload, $token ) {
        return $this->post(
            '/api/scans/' . rawurlencode( (string) $scan_id ) . '/collect-payload',
            $payload,
            $token,
            180
        );
    }

    /**
     * Fetch scan results by ID.
     */
    public function get_scan( $scan_id, $token ) {
        return $this->get( '/api/scans/' . urlencode( $scan_id ), $token );
    }

    /**
     * Get report URL for a scan.
     */
    public function get_report_url( $scan_id ) {
        return $this->base_url . '/api/reports/' . urlencode( $scan_id );
    }

    /**
     * Side-effect-free pre-publish compliance check for one product/page/post.
     *
     * @param string $token License JWT.
     * @param array  $payload Preview body (type, title, description, …).
     */
    public function check_content( $token, $payload ) {
        return $this->post( '/api/scans/preview', $payload, $token, 12 );
    }

    private function post( $endpoint, $body, $token = null, $timeout = 120 ) {
        $args = array(
            'timeout' => $timeout,
            'headers' => array(
                'Content-Type' => 'application/json',
                'Accept'       => 'application/json',
            ),
            'body'    => wp_json_encode( $body ),
        );

        if ( $token ) {
            $args['headers']['Authorization'] = 'Bearer ' . $token;
        }

        $response = wp_remote_post( $this->base_url . $endpoint, $args );
        return $this->parse_response( $response );
    }

    /**
     * @param bool $allow_empty_204 When true, HTTP 204 is treated as success with null data.
     */
    private function get( $endpoint, $token = null, $timeout = 30, $allow_empty_204 = false ) {
        $args = array(
            'timeout' => $timeout,
            'headers' => array(
                'Accept' => 'application/json',
            ),
        );

        if ( $token ) {
            $args['headers']['Authorization'] = 'Bearer ' . $token;
        }

        $response = wp_remote_get( $this->base_url . $endpoint, $args );
        return $this->parse_response( $response, $allow_empty_204 );
    }

    private function parse_response( $response, $allow_empty_204 = false ) {
        if ( is_wp_error( $response ) ) {
            return array(
                'success' => false,
                'error'   => $response->get_error_message(),
            );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $raw  = wp_remote_retrieve_body( $response );

        if ( $allow_empty_204 && 204 === (int) $code ) {
            return array(
                'success' => true,
                'data'    => null,
                'code'    => 204,
            );
        }

        $body = json_decode( $raw, true );

        if ( $code >= 200 && $code < 300 ) {
            return array(
                'success' => true,
                'data'    => $body,
                'code'    => $code,
            );
        }

        return array(
            'success' => false,
            'error'   => $this->format_api_error( is_array( $body ) ? $body : array() ),
            'status'  => is_array( $body ) && isset( $body['status'] ) ? $body['status'] : 'error',
            'code'    => $code,
            'data'    => $body,
        );
    }

    /**
     * Build a readable error message, including validation details when present.
     */
    private function format_api_error( $body ) {
        if ( ! is_array( $body ) ) {
            return 'API request failed.';
        }

        $message = isset( $body['message'] ) ? $body['message'] : ( isset( $body['error'] ) ? $body['error'] : 'API request failed.' );

        if ( empty( $body['details'] ) || ! is_array( $body['details'] ) ) {
            return $message;
        }

        $parts = array();
        foreach ( $body['details'] as $detail ) {
            if ( ! is_array( $detail ) ) {
                continue;
            }
            $path = ! empty( $detail['path'] ) && is_array( $detail['path'] ) ? implode( '.', $detail['path'] ) : '';
            $msg  = isset( $detail['message'] ) ? $detail['message'] : '';
            if ( $path && $msg ) {
                $parts[] = $path . ': ' . $msg;
            } elseif ( $msg ) {
                $parts[] = $msg;
            }
        }

        if ( $parts ) {
            $message .= ' (' . implode( '; ', array_slice( $parts, 0, 3 ) ) . ')';
        }

        return $message;
    }
}
