<?php
/**
 * REST API — lets the paired SaaS backend collect fresh store content on demand
 * (e.g. an operator-initiated scan from the SaaS dashboard).
 *
 * Requests are authenticated with an HMAC of the license key, which both the
 * plugin and the SaaS backend already share. No content is returned unless the
 * signature and a recent timestamp validate.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CM_Rest {

    const NAMESPACE = 'compliance-monitor/v1';

    /** Max clock skew (seconds) allowed between the SaaS backend and this site. */
    const MAX_TIMESTAMP_SKEW = 300;

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    public function register_routes() {
        register_rest_route(
            self::NAMESPACE,
            '/collect',
            array(
                'methods'             => 'POST',
                'callback'            => array( $this, 'handle_collect' ),
                'permission_callback' => array( $this, 'authorize_request' ),
            )
        );
    }

    /**
     * Verify the HMAC signature and timestamp against the stored license key.
     *
     * @param WP_REST_Request $request
     * @return bool|WP_Error
     */
    public function authorize_request( $request ) {
        $license = CM_License::instance();
        if ( ! $license->is_active() ) {
            return new WP_Error( 'cm_inactive_license', __( 'License is not active.', 'compliance-monitor' ), array( 'status' => 403 ) );
        }

        $license_key = trim( (string) $license->get_key() );
        if ( empty( $license_key ) ) {
            return new WP_Error( 'cm_no_license', __( 'No license key configured.', 'compliance-monitor' ), array( 'status' => 403 ) );
        }

        $timestamp = $request->get_header( 'x_cm_timestamp' );
        $signature = $request->get_header( 'x_cm_signature' );

        if ( empty( $timestamp ) || empty( $signature ) ) {
            return new WP_Error( 'cm_missing_auth', __( 'Missing authentication headers.', 'compliance-monitor' ), array( 'status' => 401 ) );
        }

        if ( abs( time() - (int) $timestamp ) > self::MAX_TIMESTAMP_SKEW ) {
            return new WP_Error( 'cm_stale_request', __( 'Request timestamp is out of range.', 'compliance-monitor' ), array( 'status' => 401 ) );
        }

        $body     = (string) $request->get_body();
        $expected = hash_hmac( 'sha256', $timestamp . '.' . $body, $license_key );

        if ( ! hash_equals( $expected, (string) $signature ) ) {
            return new WP_Error( 'cm_bad_signature', __( 'Invalid request signature.', 'compliance-monitor' ), array( 'status' => 401 ) );
        }

        return true;
    }

    /**
     * Collect and return the current store content payload.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function handle_collect( $request ) {
        // Large catalogs + rendered page fetches can exceed host defaults (often 30–60s),
        // which surfaces as HTTP 504 from the proxy in front of WordPress.
        if ( function_exists( 'ignore_user_abort' ) ) {
            ignore_user_abort( true );
        }
        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 300 );
        }

        $lean = false;
        if ( $request instanceof WP_REST_Request ) {
            $lean_header = strtolower( (string) $request->get_header( 'x_cm_collect_mode' ) );
            $lean_body   = $request->get_param( 'lean' );
            $lean        = ( 'lean' === $lean_header ) || ( true === $lean_body ) || ( '1' === (string) $lean_body ) || ( 'true' === strtolower( (string) $lean_body ) );
        }

        if ( $lean ) {
            // Lean mode: finish under typical reverse-proxy limits; skip live HTML fetches.
            add_filter( 'cm_render_fetch_enabled', '__return_false', 100 );
            add_filter( 'cm_render_fetch_max', static function () {
                return 0;
            }, 100 );
            add_filter( 'cm_render_fetch_time_budget', static function () {
                return 5;
            }, 100 );
        } else {
            // Default remote collect: tighter budgets than local admin so hosts are less likely to 504.
            add_filter( 'cm_render_fetch_max', static function ( $max ) {
                $max = (int) $max;
                return $max > 0 ? min( $max, 80 ) : 80;
            }, 5 );
            add_filter( 'cm_render_fetch_time_budget', static function ( $seconds ) {
                $seconds = (int) $seconds;
                return $seconds > 0 ? min( $seconds, 25 ) : 25;
            }, 5 );
        }

        $collector = new CM_Data_Collector();
        $payload   = $collector->collect();

        return new WP_REST_Response( $payload, 200 );
    }
}
