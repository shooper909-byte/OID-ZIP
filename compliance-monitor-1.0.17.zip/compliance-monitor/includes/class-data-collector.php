<?php
/**
 * Data collector — gathers site content for SaaS analysis.
 * No compliance rules or scoring logic lives here.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CM_Data_Collector {

    /** Number of live product-page fetches performed during this collect run. */
    private $render_fetches_used = 0;

    /** Wall-clock deadline (microtime float) for live product-page fetches. */
    private $render_deadline = null;

    /**
     * Collect all scan data from the WordPress/WooCommerce site.
     */
    public function collect() {
        $site_url = home_url();
        $parsed   = wp_parse_url( $site_url );
        $domain   = isset( $parsed['host'] ) ? $parsed['host'] : '';

        $pages    = $this->collect_pages();
        $policies = $this->collect_policies();
        $pages    = $this->merge_policy_pages_into_list( $pages, $policies );

        return array(
            'site'      => $this->collect_site_info( $site_url, $domain ),
            'products'  => $this->collect_products(),
            'pages'     => $pages,
            'posts'     => $this->collect_posts(),
            'policies'  => $policies,
            'checkout'  => $this->collect_checkout(),
            'controls'  => $this->collect_controls(),
            'scannedAt' => gmdate( 'c' ),
        );
    }

    /**
     * Ensure detected policy pages appear in the pages list for backend analysis.
     */
    private function merge_policy_pages_into_list( $pages, $policies ) {
        $existing = array();
        foreach ( $pages as $page ) {
            $existing[ (string) $page['id'] ] = true;
            if ( ! empty( $page['slug'] ) ) {
                $existing[ 'slug:' . $page['slug'] ] = true;
            }
        }

        foreach ( $policies as $policy ) {
            if ( empty( $policy ) || empty( $policy['detected'] ) ) {
                continue;
            }
            $id_key   = (string) $policy['id'];
            $slug_key = ! empty( $policy['slug'] ) ? 'slug:' . $policy['slug'] : '';
            if ( isset( $existing[ $id_key ] ) || ( $slug_key && isset( $existing[ $slug_key ] ) ) ) {
                continue;
            }
            $pages[] = array(
                'id'      => $policy['id'],
                'title'   => $policy['title'],
                'content' => $policy['content'],
                'slug'    => $policy['slug'],
                'url'     => $policy['url'],
                'type'    => 'page',
            );
        }

        return $pages;
    }

    private function collect_site_info( $url, $domain ) {
        return array(
            'name'           => get_bloginfo( 'name' ),
            'url'            => $url,
            'domain'         => preg_replace( '/^www\./', '', $domain ),
            'contactEmail'   => get_option( 'admin_email', '' ),
            'contactPhone'   => get_option( 'cm_contact_phone', '' ),
            'contactAddress' => get_option( 'cm_contact_address', '' ),
            'plugins'        => function_exists( 'cm_installed_plugins_snapshot' )
                ? cm_installed_plugins_snapshot()
                : array(),
        );
    }

    private function collect_products() {
        if ( ! function_exists( 'wc_get_products' ) ) {
            return array();
        }

        $products = wc_get_products( array(
            'limit'  => 500,
            'status' => 'publish',
            'return' => 'objects',
        ) );

        $data = array();
        foreach ( $products as $product ) {
            $image_alts = array();
            $image_id   = $product->get_image_id();
            if ( $image_id ) {
                $alt = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
                if ( $alt ) {
                    $image_alts[] = $alt;
                }
            }
            $gallery_ids = $product->get_gallery_image_ids();
            foreach ( $gallery_ids as $gid ) {
                $alt = get_post_meta( $gid, '_wp_attachment_image_alt', true );
                if ( $alt ) {
                    $image_alts[] = $alt;
                }
            }

            $categories = wp_get_post_terms( $product->get_id(), 'product_cat', array( 'fields' => 'names' ) );
            $tags       = wp_get_post_terms( $product->get_id(), 'product_tag', array( 'fields' => 'names' ) );

            $data[] = array(
                'id'               => $product->get_id(),
                'title'            => $product->get_name(),
                'description'      => wp_strip_all_tags( $product->get_description() ),
                'shortDescription' => wp_strip_all_tags( $product->get_short_description() ),
                'categories'       => is_array( $categories ) ? $categories : array(),
                'tags'             => is_array( $tags ) ? $tags : array(),
                'sku'              => (string) $product->get_sku(),
                'url'              => $this->safe_permalink( $product->get_id() ),
                'imageAltTexts'    => $image_alts,
                'images'           => $this->collect_product_images( $product ),
                'metaTitle'        => $this->get_meta_title( $product->get_id() ),
                'metaDescription'  => $this->get_meta_description( $product->get_id() ),
                'attributes'       => $this->collect_product_attributes( $product ),
                'customFields'     => $this->collect_product_custom_fields( $product ),
                'downloads'        => $this->collect_product_download_entries( $product ),
                'renderedContent'  => $this->collect_product_rendered_content( $product ),
            );
        }

        return $data;
    }

    /**
     * Structured featured/gallery image metadata (URLs only — no binaries).
     * Caps at 20 entries to keep scan payloads bounded.
     *
     * @param WC_Product $product Product.
     * @return array<int,array<string,mixed>>
     */
    private function collect_product_images( $product ) {
        $images = array();
        $seen   = array();

        $featured_id = $product->get_image_id();
        if ( $featured_id ) {
            $entry = $this->format_product_image( (int) $featured_id, 'featured' );
            if ( $entry ) {
                $seen[ (string) $featured_id ] = true;
                $images[] = $entry;
            }
        }

        $gallery_ids = $product->get_gallery_image_ids();
        foreach ( $gallery_ids as $gid ) {
            if ( count( $images ) >= 20 ) {
                break;
            }
            $gid = (int) $gid;
            if ( ! $gid || isset( $seen[ (string) $gid ] ) ) {
                continue;
            }
            $entry = $this->format_product_image( $gid, 'gallery' );
            if ( $entry ) {
                $seen[ (string) $gid ] = true;
                $images[] = $entry;
            }
        }

        return $images;
    }

    /**
     * @param int    $attachment_id Attachment post ID.
     * @param string $role          featured|gallery.
     * @return array<string,mixed>|null
     */
    private function format_product_image( $attachment_id, $role ) {
        $url = wp_get_attachment_url( $attachment_id );
        if ( ! is_string( $url ) || '' === $url ) {
            return null;
        }

        $alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
        $entry = array(
            'attachmentId' => $attachment_id,
            'url'          => $url,
            'alt'          => is_string( $alt ) ? $alt : '',
            'role'         => $role,
        );

        $mime = get_post_mime_type( $attachment_id );
        if ( is_string( $mime ) && '' !== $mime ) {
            $entry['mimeType'] = $mime;
        }

        $modified = get_post_modified_time( 'c', true, $attachment_id );
        if ( is_string( $modified ) && '' !== $modified ) {
            $entry['modifiedAt'] = $modified;
        }

        return $entry;
    }

    /**
     * Merge WooCommerce downloads + attached/meta PDFs, enrich metadata, dedupe by URL/file.
     *
     * @param WC_Product $product Product.
     * @return array<int,array<string,mixed>>
     */
    private function collect_product_download_entries( $product ) {
        $merged = array_merge(
            $this->collect_product_downloads( $product ),
            $this->collect_product_attached_pdfs( $product )
        );

        $result = array();
        $seen   = array();

        foreach ( $merged as $entry ) {
            if ( count( $result ) >= 25 ) {
                break;
            }

            $file = isset( $entry['file'] ) ? (string) $entry['file'] : '';
            $name = isset( $entry['name'] ) ? (string) $entry['name'] : '';
            if ( '' === $file && '' === $name ) {
                continue;
            }

            $dedupe_key = '' !== $file ? strtolower( $file ) : ( 'name:' . strtolower( $name ) );
            if ( isset( $seen[ $dedupe_key ] ) ) {
                continue;
            }
            $seen[ $dedupe_key ] = true;
            $result[] = $entry;
        }

        return $result;
    }

    /**
     * Collect WooCommerce product attributes ("Additional Information" rows) as
     * "name: value" strings. This is where merchants commonly store CAS numbers,
     * batch/lot references, and purity/COA notes.
     */
    private function collect_product_attributes( $product ) {
        $result = array();

        if ( ! method_exists( $product, 'get_attributes' ) ) {
            return $result;
        }

        foreach ( $product->get_attributes() as $attribute ) {
            $name   = '';
            $values = array();

            if ( is_object( $attribute ) && method_exists( $attribute, 'get_name' ) ) {
                $name = wc_attribute_label( $attribute->get_name() );

                if ( $attribute->is_taxonomy() ) {
                    $terms = wc_get_product_terms( $product->get_id(), $attribute->get_name(), array( 'fields' => 'names' ) );
                    if ( is_array( $terms ) ) {
                        $values = $terms;
                    }
                } else {
                    $values = $attribute->get_options();
                }
            } elseif ( is_string( $attribute ) ) {
                // Legacy/custom meta attribute stored as a plain string.
                $values = array( $attribute );
            }

            $values = array_filter( array_map( 'wp_strip_all_tags', (array) $values ), 'strlen' );
            if ( empty( $values ) ) {
                continue;
            }

            $joined = implode( ', ', $values );
            $result[] = $name ? ( $name . ': ' . $joined ) : $joined;
        }

        return array_values( array_unique( $result ) );
    }

    /**
     * Collect downloadable files (e.g. COA PDFs) attached to a product so linked
     * certificates are visible to the scanner.
     *
     * @param WC_Product $product Product.
     * @return array<int,array<string,mixed>>
     */
    private function collect_product_downloads( $product ) {
        $result = array();

        if ( ! method_exists( $product, 'get_downloads' ) ) {
            return $result;
        }

        foreach ( $product->get_downloads() as $download ) {
            $name = '';
            $file = '';

            if ( is_object( $download ) ) {
                if ( method_exists( $download, 'get_name' ) ) {
                    $name = (string) $download->get_name();
                }
                if ( method_exists( $download, 'get_file' ) ) {
                    $file = (string) $download->get_file();
                }
            } elseif ( is_array( $download ) ) {
                $name = isset( $download['name'] ) ? (string) $download['name'] : '';
                $file = isset( $download['file'] ) ? (string) $download['file'] : '';
            }

            if ( '' === $name && '' === $file ) {
                continue;
            }

            $result[] = $this->enrich_download_entry(
                array(
                    'name' => wp_strip_all_tags( $name ),
                    'file' => $file,
                ),
                'woocommerce'
            );
        }

        return $result;
    }

    /**
     * Collect PDFs attached to the product post (media library children / attached media).
     * Many "View COAs" widgets link these instead of WooCommerce downloadable files.
     *
     * @param WC_Product $product Product.
     * @return array<int,array<string,mixed>>
     */
    private function collect_product_attached_pdfs( $product ) {
        $result     = array();
        $product_id = $product->get_id();

        $attachments = get_attached_media( 'application/pdf', $product_id );
        foreach ( $attachments as $attachment ) {
            $url  = wp_get_attachment_url( $attachment->ID );
            $name = get_the_title( $attachment );
            if ( ! $url && ! $name ) {
                continue;
            }
            $result[] = $this->enrich_download_entry(
                array(
                    'name'         => wp_strip_all_tags( (string) $name ),
                    'file'         => (string) $url,
                    'attachmentId' => (int) $attachment->ID,
                ),
                'attachment',
                (int) $attachment->ID
            );
        }

        // Also scan product meta values for PDF URLs (common COA plugin storage).
        $all = get_post_meta( $product_id );
        if ( is_array( $all ) ) {
            foreach ( $all as $key => $values ) {
                $key_l = strtolower( (string) $key );
                if ( false === strpos( $key_l, 'coa' )
                    && false === strpos( $key_l, 'certificate' )
                    && false === strpos( $key_l, 'pdf' )
                    && false === strpos( $key_l, 'document' ) ) {
                    continue;
                }
                foreach ( (array) $values as $raw ) {
                    $raw = is_string( $raw ) ? $raw : ( is_numeric( $raw ) ? (string) $raw : wp_json_encode( $raw ) );
                    if ( ! is_string( $raw ) || '' === $raw ) {
                        continue;
                    }
                    if ( preg_match_all( '/https?:\/\/[^\s"\'<>]+\.pdf\b/i', $raw, $m ) ) {
                        foreach ( $m[0] as $url ) {
                            $result[] = $this->enrich_download_entry(
                                array(
                                    'name' => (string) $key,
                                    'file' => $url,
                                ),
                                'meta'
                            );
                        }
                    } elseif ( preg_match( '/\.pdf\b/i', $raw ) ) {
                        $result[] = $this->enrich_download_entry(
                            array(
                                'name' => (string) $key,
                                'file' => trim( wp_strip_all_tags( $raw ) ),
                            ),
                            'meta'
                        );
                    }
                }
            }
        }

        return $result;
    }

    /**
     * Add attachment/MIME/role/source metadata to a download entry without removing name/file.
     *
     * @param array<string,mixed> $entry           Base entry with name/file.
     * @param string              $source          woocommerce|attachment|meta.
     * @param int|null            $attachment_id   Known attachment ID, if any.
     * @return array<string,mixed>
     */
    private function enrich_download_entry( $entry, $source, $attachment_id = null ) {
        $name = isset( $entry['name'] ) ? (string) $entry['name'] : '';
        $file = isset( $entry['file'] ) ? (string) $entry['file'] : '';

        if ( null === $attachment_id && isset( $entry['attachmentId'] ) ) {
            $attachment_id = absint( $entry['attachmentId'] );
            if ( ! $attachment_id ) {
                $attachment_id = null;
            }
        }

        if ( null === $attachment_id && '' !== $file && function_exists( 'attachment_url_to_postid' ) ) {
            $resolved = absint( attachment_url_to_postid( $file ) );
            if ( $resolved ) {
                $attachment_id = $resolved;
            }
        }

        $out = array(
            'name'   => $name,
            'file'   => $file,
            'source' => $source,
            'role'   => $this->infer_download_role( $name, $file ),
        );

        if ( null !== $attachment_id && $attachment_id > 0 ) {
            $out['attachmentId'] = $attachment_id;

            $mime = get_post_mime_type( $attachment_id );
            if ( is_string( $mime ) && '' !== $mime ) {
                $out['mimeType'] = $mime;
            }

            $modified = get_post_modified_time( 'c', true, $attachment_id );
            if ( is_string( $modified ) && '' !== $modified ) {
                $out['modifiedAt'] = $modified;
            }
        }

        if ( empty( $out['mimeType'] ) ) {
            $guessed = $this->guess_mime_from_path( $file );
            if ( $guessed ) {
                $out['mimeType'] = $guessed;
            }
        }

        return $out;
    }

    /**
     * Classify a download as a COA-like document vs a generic product download.
     *
     * @param string $name Display name.
     * @param string $file File path or URL.
     * @return string coa|download
     */
    private function infer_download_role( $name, $file ) {
        $haystack = strtolower( $name . ' ' . $file );
        if ( preg_match( '/\bcoa\b|c\.?o\.?a\.?|certificate(?:\s+of\s+analysis)?/i', $haystack ) ) {
            return 'coa';
        }
        return 'download';
    }

    /**
     * Best-effort MIME hint from file extension when no attachment meta exists.
     *
     * @param string $path File path or URL.
     * @return string|null
     */
    private function guess_mime_from_path( $path ) {
        $path = strtolower( (string) $path );
        if ( preg_match( '/\.pdf(?:[?#]|$)/', $path ) ) {
            return 'application/pdf';
        }
        if ( preg_match( '/\.(png|jpe?g|gif|webp|svg)(?:[?#]|$)/', $path, $m ) ) {
            $ext = $m[1];
            if ( 'jpg' === $ext || 'jpeg' === $ext ) {
                return 'image/jpeg';
            }
            if ( 'svg' === $ext ) {
                return 'image/svg+xml';
            }
            return 'image/' . $ext;
        }
        return null;
    }

    /**
     * Capture the product's fully-rendered content so information added via
     * page-builder blocks or theme templates/hooks (which never lands in the
     * structured WooCommerce fields) is still visible to the scanner.
     *
     * Layers:
     *   1. Local render of the product post — Gutenberg / shortcodes / Elementor.
     *   2. Bounded, cached fetch of the live product URL (theme/hook output).
     * Custom Product Data fields are sent separately as customFields.
     */
    private function collect_product_rendered_content( $product ) {
        $parts = array();

        $local = $this->extract_page_text( get_post( $product->get_id() ) );
        if ( '' !== $local ) {
            $parts[] = $local;
        }

        // Also fold custom fields into rendered text so presence checks that only
        // read renderedContent still see Product Data values.
        $custom = $this->collect_product_custom_fields( $product );
        if ( ! empty( $custom ) ) {
            $parts[] = implode( ' ', $custom );
        }

        $live = $this->fetch_rendered_product_text( $product );
        if ( '' !== $live ) {
            $parts[] = $live;
        }

        $combined = trim( preg_replace( '/\s+/', ' ', implode( ' ', $parts ) ) );

        return strlen( $combined ) > 50000 ? substr( $combined, 0, 50000 ) : $combined;
    }

    /**
     * Collect Product Data / theme / ACF / plugin custom fields as "Label: value"
     * strings. This is where merchants often store CAS, lot, purity, etc. under
     * a Product Details tab — values that never appear in description HTML.
     *
     * @param WC_Product $product Product object.
     * @return string[]
     */
    private function collect_product_custom_fields( $product ) {
        $product_id = $product->get_id();
        $flat       = array();

        // WooCommerce meta API (preferred) + raw post meta fallback.
        if ( method_exists( $product, 'get_meta_data' ) ) {
            foreach ( $product->get_meta_data() as $meta ) {
                if ( ! is_object( $meta ) || ! isset( $meta->key ) ) {
                    continue;
                }
                $this->flatten_meta_value( (string) $meta->key, $meta->value, $flat );
            }
        }

        $all = get_post_meta( $product_id );
        if ( is_array( $all ) ) {
            foreach ( $all as $key => $values ) {
                foreach ( (array) $values as $raw ) {
                    // get_post_meta( $id ) returns already-unserialized values.
                    $this->flatten_meta_value( (string) $key, maybe_unserialize( $raw ), $flat );
                }
            }
        }

        $result = array();
        foreach ( $flat as $key => $value ) {
            if ( ! $this->is_relevant_product_field( $key, $value ) ) {
                continue;
            }
            $label    = $this->humanize_meta_key( $key );
            $result[] = $label . ': ' . $value;
        }

        return array_values( array_unique( $result ) );
    }

    /**
     * Recursively flatten nested meta (serialized Product Details groups, ACF, etc.)
     * into dotted keys → scalar string values.
     *
     * @param string               $key    Meta key / path.
     * @param mixed                $value  Meta value.
     * @param array<string,string> $out    Accumulator.
     * @param int                  $depth  Recursion depth.
     */
    private function flatten_meta_value( $key, $value, &$out, $depth = 0 ) {
        if ( $depth > 4 || strlen( (string) $key ) > 160 ) {
            return;
        }

        if ( is_object( $value ) ) {
            $value = (array) $value;
        }

        if ( is_array( $value ) ) {
            foreach ( $value as $child_key => $child_val ) {
                $child_key = is_string( $child_key ) || is_int( $child_key ) ? (string) $child_key : '';
                if ( '' === $child_key || is_numeric( $child_key ) ) {
                    // List items: keep parent key so "CAS" group labels still match.
                    $this->flatten_meta_value( $key, $child_val, $out, $depth + 1 );
                } else {
                    $this->flatten_meta_value( $key . '.' . $child_key, $child_val, $out, $depth + 1 );
                }
            }
            return;
        }

        if ( ! is_string( $value ) && ! is_numeric( $value ) ) {
            return;
        }

        $text = wp_strip_all_tags( (string) $value );
        $text = trim( preg_replace( '/\s+/', ' ', $text ) );
        if ( '' === $text || strlen( $text ) > 2000 ) {
            return;
        }

        // Prefer first non-empty value for a key.
        if ( ! isset( $out[ $key ] ) || '' === $out[ $key ] ) {
            $out[ $key ] = $text;
        }
    }

    /**
     * Whether a flattened meta key/value should be sent for compliance scanning.
     */
    private function is_relevant_product_field( $key, $value ) {
        $key = (string) $key;

        if ( $this->is_internal_meta_key( $key ) ) {
            return false;
        }

        // Keyword in key or value (CAS, COA, lot, Product Details, etc.).
        $keyword = '/cas|coa|batch|lot|certificate|analysis|purity|assay|\bmw\b|molecular|sequence|formula|peptide|compound|spec(?:ification)?|product[_\s-]?detail/i';
        if ( preg_match( $keyword, $key ) || preg_match( $keyword, $value ) ) {
            return true;
        }

        // Bare CAS registry numbers even under opaque keys.
        if ( preg_match( '/\b\d{2,7}-\d{2}-\d\b/', $value ) ) {
            return true;
        }

        return false;
    }

    /**
     * Skip Woo/WP internal meta that is never a Product Details field.
     *
     * Rank Math / Yoast keys are normalized before matching so leftovers stored
     * as `_rank_math_description`, `rank-math-description`, or a pretty custom
     * field named `Rank Math Description` are not emitted as customFields.
     * Those leftovers humanize to "Rank Math Description: …" and get phrase-
     * scanned even when the live <meta name="description"> is already clean.
     */
    private function is_internal_meta_key( $key ) {
        $key = strtolower( (string) $key );

        $normalized = preg_replace( '/^_+/', '', $key );
        $normalized = str_replace( array( '.', '-', ' ' ), '_', (string) $normalized );
        $normalized = preg_replace( '/_+/', '_', (string) $normalized );

        if ( 0 === strpos( $normalized, 'rank_math' ) || false !== strpos( $normalized, '_rank_math' ) ) {
            return true;
        }
        if (
            0 === strpos( $normalized, 'yoast' )
            || 0 === strpos( $normalized, 'wpseo' )
            || false !== strpos( $normalized, '_yoast' )
            || false !== strpos( $normalized, '_wpseo' )
        ) {
            return true;
        }

        $exact = array(
            '_edit_lock',
            '_edit_last',
            '_thumbnail_id',
            '_wp_page_template',
            '_wp_desired_post_slug',
            '_wp_old_slug',
            '_product_attributes',
            '_product_version',
            '_product_image_gallery',
            '_default_attributes',
            '_children',
            '_downloadable_files',
            '_download_limit',
            '_download_expiry',
            '_file_paths',
            '_wc_rating_count',
            '_wc_review_count',
            '_wc_average_rating',
            '_sold_individually',
            '_manage_stock',
            '_stock',
            '_stock_status',
            '_backorders',
            '_low_stock_amount',
            '_price',
            '_regular_price',
            '_sale_price',
            '_sale_price_dates_from',
            '_sale_price_dates_to',
            '_tax_status',
            '_tax_class',
            '_weight',
            '_length',
            '_width',
            '_height',
            '_sku',
            '_virtual',
            '_downloadable',
            '_featured',
            '_visibility',
            '_purchase_note',
            'total_sales',
        );
        if ( in_array( $key, $exact, true ) ) {
            return true;
        }

        $prefixes = array(
            '_edit_',
            '_wp_',
            '_oembed',
            '_elementor',
            '_yoast',
            'rank_math',
            '_wc_paypal',
            '_stripe',
            '_transient',
            '_site_transient',
        );
        foreach ( $prefixes as $prefix ) {
            if ( 0 === strpos( $key, $prefix ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Turn meta keys like "cas_number" / "_product_details.cas" into readable labels.
     */
    private function humanize_meta_key( $key ) {
        $key = preg_replace( '/^_+/', '', (string) $key );
        $key = str_replace( array( '.', '-', '_' ), ' ', $key );
        $key = preg_replace( '/\s+/', ' ', $key );
        return ucwords( trim( $key ) );
    }

    /**
     * Fetch and cache the rendered frontend HTML text for a product page.
     *
     * Bounded by a per-run count and time budget so large catalogs never time
     * out the synchronous /collect request, and cached per product-modified
     * time so repeat scans mostly serve from cache. All limits are filterable:
     *   - cm_render_fetch_enabled      (bool, default true)
     *   - cm_render_fetch_max          (int max fetches per run, default 250)
     *   - cm_render_fetch_time_budget  (int seconds per run, default 45)
     */
    private function fetch_rendered_product_text( $product ) {
        if ( ! apply_filters( 'cm_render_fetch_enabled', true ) ) {
            return '';
        }

        $product_id = $product->get_id();
        $modified   = (string) get_post_modified_time( 'U', true, $product_id );
        // Bump cache key version when extraction logic changes.
        $cache_key  = 'cm_rend_v4_' . $product_id . '_' . $modified;

        $cached = get_transient( $cache_key );
        if ( false !== $cached ) {
            return is_string( $cached ) ? $cached : '';
        }

        if ( ! $this->render_budget_available() ) {
            return '';
        }

        $url = $this->safe_permalink( $product_id );
        if ( '' === $url ) {
            return '';
        }

        $this->render_fetches_used++;

        $response = $this->request_product_page( $url );
        $text     = '';
        $ok       = false;

        if ( ! is_wp_error( $response ) ) {
            $code = wp_remote_retrieve_response_code( $response );
            $body = (string) wp_remote_retrieve_body( $response );
            if ( $code >= 200 && $code < 400 && ! $this->looks_like_age_gate( $body ) ) {
                $text = $this->html_to_scan_text( $body );
                $ok   = '' !== $text;
            }
        }

        // Successful extractions: cache 12h. Failures/age-gates: short TTL so
        // the next scan can retry instead of locking in empty content.
        set_transient( $cache_key, $text, $ok ? 12 * HOUR_IN_SECONDS : 5 * MINUTE_IN_SECONDS );

        return $text;
    }

    /**
     * HTTP GET for a product page, with Compliance Monitor collect token so the
     * Beacon age gate (and similar) can allow the loopback through.
     */
    private function request_product_page( $url ) {
        $args = array(
            'timeout'     => 10,
            'redirection' => 3,
            'sslverify'   => false,
            'headers'     => array(
                'X-CM-Collect-Token' => hash_hmac( 'sha256', 'beacon-cm-collect', wp_salt( 'auth' ) ),
                'User-Agent'        => 'BeaconComplianceMonitor/' . ( defined( 'CM_VERSION' ) ? CM_VERSION : '1.0' ),
            ),
        );

        $response = wp_remote_get( $url, $args );
        if ( ! is_wp_error( $response ) ) {
            return $response;
        }

        // Some hosts block loopback to their public hostname; retry via 127.0.0.1.
        $parsed = wp_parse_url( $url );
        if ( empty( $parsed['host'] ) || empty( $parsed['scheme'] ) ) {
            return $response;
        }

        $path  = isset( $parsed['path'] ) ? $parsed['path'] : '/';
        $query = isset( $parsed['query'] ) ? ( '?' . $parsed['query'] ) : '';
        $local = $parsed['scheme'] . '://127.0.0.1' . $path . $query;

        $args['headers']['Host'] = $parsed['host'];
        return wp_remote_get( $local, $args );
    }

    /**
     * Convert HTML to searchable text, preserving URLs and labels that often
     * hold COA signals ("View COAs" buttons, data-attrs, PDF hrefs).
     */
    private function html_to_scan_text( $body ) {
        $body = (string) $body;
        $extra = array();

        // href / src (PDF links in modals often live here).
        if ( preg_match_all( '/\b(?:href|src)=["\']([^"\']+)["\']/i', $body, $matches ) ) {
            $extra = array_merge( $extra, $matches[1] );
        }

        // Button/link accessibility and plugin data attributes ("View COAs", file URLs).
        if ( preg_match_all(
            '/\b(?:aria-label|title|alt|data-(?:title|label|text|name|file|url|pdf|href|document|src|coas?|certificate))=["\']([^"\']+)["\']/i',
            $body,
            $matches
        ) ) {
            $extra = array_merge( $extra, $matches[1] );
        }

        // Class / id tokens that mention COA (common for COA lightbox widgets).
        if ( preg_match_all( '/\b(?:class|id)=["\']([^"\']*\bcoa[^"\']*)["\']/i', $body, $matches ) ) {
            $extra = array_merge( $extra, $matches[1] );
        }

        // Any bare .pdf URL-ish tokens in the markup (JSON-embedded modal configs).
        if ( preg_match_all( '/https?:\/\/[^\s"\'<>]+\.pdf\b|[^\s"\'<>]*coa[^\s"\'<>]*\.pdf\b/i', $body, $matches ) ) {
            $extra = array_merge( $extra, $matches[0] );
        }

        $stripped = preg_replace( '#<(script|style|noscript)\b[^>]*>.*?</\1>#is', ' ', $body );
        $text     = wp_strip_all_tags( (string) $stripped );
        if ( ! empty( $extra ) ) {
            $text .= ' ' . implode( ' ', array_unique( $extra ) );
        }
        $text = trim( preg_replace( '/\s+/', ' ', $text ) );
        if ( strlen( $text ) > 50000 ) {
            $text = substr( $text, 0, 50000 );
        }
        return $text;
    }

    /**
     * Detect Beacon (or similar) age-gate interstitial HTML.
     */
    private function looks_like_age_gate( $body ) {
        if ( ! is_string( $body ) || '' === $body ) {
            return true;
        }
        return (bool) preg_match(
            '/beacon-age-gate|beacon_sc_age_enter|beacon_sc_ack_|beacon_sc_entry_terms|laboratory research materials supplier|you must be \d+ years of age|confirm the statements below|age verification|enter.*\b\d{2}\+\b/i',
            $body
        );
    }

    /**
     * Whether another live product-page fetch is allowed under this run's budget.
     */
    private function render_budget_available() {
        $max = (int) apply_filters( 'cm_render_fetch_max', 250 );
        if ( $max > 0 && $this->render_fetches_used >= $max ) {
            return false;
        }

        if ( null === $this->render_deadline ) {
            $budget                = (int) apply_filters( 'cm_render_fetch_time_budget', 45 );
            $this->render_deadline = microtime( true ) + max( 1, $budget );
        }

        return microtime( true ) < $this->render_deadline;
    }

    private function collect_pages() {
        $pages = get_pages( array(
            'post_status' => array( 'publish', 'private' ),
            'sort_column' => 'post_title',
            'sort_order'  => 'ASC',
            'number'      => 0,
        ) );

        $data = array();
        foreach ( $pages as $page ) {
            $data[] = array(
                'id'              => $page->ID,
                'title'           => $page->post_title,
                'content'         => $this->extract_page_text( $page ),
                'slug'            => $page->post_name,
                'url'             => $this->safe_permalink( $page->ID ),
                'type'            => 'page',
                'metaTitle'       => $this->get_meta_title( $page->ID ),
                'metaDescription' => $this->get_meta_description( $page->ID ),
            );
        }

        return $data;
    }

    private function collect_posts() {
        $posts = get_posts( array(
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => 100,
        ) );

        $data = array();
        foreach ( $posts as $post ) {
            $data[] = array(
                'id'      => $post->ID,
                'title'   => $post->post_title,
                'content' => $this->extract_page_text( $post ),
                'url'     => $this->safe_permalink( $post->ID ),
            );
        }

        return $data;
    }

    private function collect_policies() {
        return array(
            'terms'    => $this->get_policy_page( 'terms' ),
            'privacy'  => $this->get_policy_page( 'privacy' ),
            'refund'   => $this->get_policy_page( 'refund' ),
            'shipping' => $this->get_policy_page( 'shipping' ),
        );
    }

    private function get_policy_page( $type ) {
        $page_id = $this->resolve_policy_page_id( $type );

        if ( $page_id ) {
            $formatted = $this->format_policy_from_post( $page_id, $type );
            if ( $formatted ) {
                return $formatted;
            }
        }

        // Last resort: fetch known policy URLs (handles page builders, custom routes, etc.)
        return $this->probe_policy_url( $type );
    }

    private function resolve_policy_page_id( $type ) {
        $page_id = 0;

        switch ( $type ) {
            case 'terms':
                $page_id = $this->normalize_page_id( wc_terms_and_conditions_page_id() );
                if ( ! $page_id ) {
                    $page_id = $this->find_page_by_slug( array(
                        'terms-and-conditions',
                        'terms',
                        'terms-of-service',
                        'terms-of-use',
                        'terms-conditions',
                    ) );
                }
                if ( ! $page_id ) {
                    $page_id = $this->find_page_by_title( array( 'terms and conditions', 'terms of service', 'terms of use' ) );
                }
                break;
            case 'privacy':
                $page_id = $this->normalize_page_id( get_option( 'wp_page_for_privacy_policy', 0 ) );
                if ( ! $page_id ) {
                    $page_id = $this->find_page_by_slug( array(
                        'privacy-policy',
                        'privacy',
                        'privacy-notice',
                    ) );
                }
                if ( ! $page_id ) {
                    $page_id = $this->find_page_by_title( array( 'privacy policy', 'privacy notice' ) );
                }
                break;
            case 'refund':
                $page_id = $this->find_page_by_slug( array( 'refund-policy', 'refund', 'returns-policy', 'return-policy' ) );
                break;
            case 'shipping':
                $page_id = $this->find_page_by_slug( array( 'shipping-policy', 'delivery-policy' ) );
                break;
        }

        return $page_id;
    }

    private function format_policy_from_post( $page_id, $type ) {
        $page = get_post( $page_id );
        if ( ! $page || 'page' !== $page->post_type || 'trash' === $page->post_status ) {
            return null;
        }

        return array(
            'id'       => $page->ID,
            'title'    => $page->post_title,
            'content'  => $this->extract_page_text( $page ),
            'slug'     => $page->post_name,
            'url'      => $this->safe_permalink( $page->ID ),
            'type'     => $type,
            'detected' => true,
        );
    }

    /**
     * Fetch a policy page by probing common URLs when WP page lookup fails.
     */
    private function probe_policy_url( $type ) {
        $paths = array(
            'privacy'  => array( '/privacy-policy/', '/privacy-policy', '/privacy/' ),
            'terms'    => array( '/terms-and-conditions/', '/terms-and-conditions', '/terms/', '/terms-of-service/' ),
            'refund'   => array( '/refund-policy/', '/refund-policy', '/returns-policy/', '/return-policy/' ),
            'shipping' => array( '/shipping-policy/', '/shipping-policy', '/delivery-policy/' ),
        );

        if ( empty( $paths[ $type ] ) ) {
            return null;
        }

        foreach ( $paths[ $type ] as $path ) {
            $url    = home_url( $path );
            $policy = $this->fetch_policy_from_url( $url, $type, trim( $path, '/' ) );
            if ( $policy ) {
                return $policy;
            }
        }

        return null;
    }

    private function fetch_policy_from_url( $url, $type, $slug ) {
        $response = wp_remote_get(
            $url,
            array(
                'timeout'     => 15,
                'redirection' => 5,
                'sslverify'   => false,
            )
        );

        if ( is_wp_error( $response ) ) {
            return null;
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code < 200 || $code >= 400 ) {
            return null;
        }

        $body = wp_remote_retrieve_body( $response );
        if ( strlen( $body ) < 200 ) {
            return null;
        }

        $text = wp_strip_all_tags( $body );
        $text = preg_replace( '/\s+/', ' ', $text );
        $text = trim( $text );

        if ( strlen( $text ) < 100 ) {
            return null;
        }

        // Skip WordPress default 404 pages.
        if ( false !== stripos( $text, 'page not found' ) && strlen( $text ) < 500 ) {
            return null;
        }

        $title = ucwords( str_replace( '-', ' ', $slug ) );
        if ( preg_match( '/<title[^>]*>(.*?)<\/title>/is', $body, $matches ) ) {
            $parsed_title = wp_strip_all_tags( $matches[1] );
            if ( strlen( trim( $parsed_title ) ) > 0 ) {
                $title = trim( $parsed_title );
            }
        }

        return array(
            'id'       => 'url-' . $type,
            'title'    => $title,
            'content'  => substr( $text, 0, 50000 ),
            'slug'     => basename( $slug ) ?: $type,
            'url'      => $url,
            'type'     => $type,
            'detected' => true,
        );
    }

    /**
     * Resolve WooCommerce/WP policy page IDs, ignoring invalid sentinels like -1.
     */
    private function normalize_page_id( $page_id ) {
        $page_id = absint( $page_id );
        return $page_id > 0 ? $page_id : 0;
    }

    /**
     * Extract readable text from a page/post, handling blocks and page builders.
     */
    private function extract_page_text( $post ) {
        if ( ! $post || empty( $post->post_content ) ) {
            return $this->extract_builder_content( $post );
        }

        $content = $post->post_content;

        if ( function_exists( 'do_blocks' ) && function_exists( 'has_blocks' ) && has_blocks( $content ) ) {
            $content = do_blocks( $content );
        }

        $content = do_shortcode( $content );
        $text    = wp_strip_all_tags( apply_filters( 'the_content', $content ) );

        if ( strlen( trim( $text ) ) > 0 ) {
            return trim( $text );
        }

        $text = wp_strip_all_tags( $content );
        if ( strlen( trim( $text ) ) > 0 ) {
            return trim( $text );
        }

        return $this->extract_builder_content( $post );
    }

    /**
     * Fallback for Elementor and similar builders that store content outside post_content.
     */
    private function extract_builder_content( $post ) {
        if ( ! $post ) {
            return '';
        }

        if ( defined( 'ELEMENTOR_VERSION' ) && class_exists( '\Elementor\Plugin' ) ) {
            $elementor = \Elementor\Plugin::$instance;
            if ( $elementor && isset( $elementor->frontend ) ) {
                $rendered = $elementor->frontend->get_builder_content( $post->ID, true );
                $text     = wp_strip_all_tags( $rendered );
                if ( strlen( trim( $text ) ) > 0 ) {
                    return trim( $text );
                }
            }
        }

        return '';
    }

    /**
     * get_permalink() can return false; API expects a string.
     */
    private function safe_permalink( $post_id ) {
        $url = get_permalink( $post_id );
        return is_string( $url ) ? $url : '';
    }

    private function find_page_by_slug( $slugs ) {
        $statuses = array( 'publish', 'private', 'draft', 'pending' );

        foreach ( $slugs as $slug ) {
            $page = get_page_by_path( $slug, OBJECT, 'page' );
            if ( $page && 'trash' !== $page->post_status ) {
                return $page->ID;
            }
        }

        foreach ( $slugs as $slug ) {
            $pages = get_posts( array(
                'post_type'      => 'page',
                'post_status'    => $statuses,
                'name'           => $slug,
                'posts_per_page' => 1,
                'fields'         => 'ids',
            ) );
            if ( ! empty( $pages ) ) {
                return $pages[0];
            }

            // Nested pages: search by post_name regardless of hierarchy.
            $query = new WP_Query( array(
                'post_type'              => 'page',
                'post_status'            => $statuses,
                'name'                   => $slug,
                'posts_per_page'         => 1,
                'fields'                 => 'ids',
                'no_found_rows'          => true,
                'update_post_meta_cache' => false,
                'update_post_term_cache' => false,
            ) );
            if ( ! empty( $query->posts ) ) {
                return $query->posts[0];
            }
        }

        return 0;
    }

    private function find_page_by_title( $title_keywords ) {
        $pages = get_posts( array(
            'post_type'      => 'page',
            'post_status'    => array( 'publish', 'private', 'draft' ),
            'posts_per_page' => 200,
        ) );

        foreach ( $pages as $page ) {
            $title = strtolower( $page->post_title );
            foreach ( $title_keywords as $keyword ) {
                if ( false !== strpos( $title, strtolower( $keyword ) ) ) {
                    return $page->ID;
                }
            }
        }

        return 0;
    }

    private function collect_checkout() {
        $notices = array();

        // Collect checkout-related option text if available.
        $checkout_page_id = wc_get_page_id( 'checkout' );
        if ( $checkout_page_id ) {
            $checkout_page = get_post( $checkout_page_id );
            if ( $checkout_page ) {
                $notices[] = wp_strip_all_tags( $checkout_page->post_content );
            }
        }

        return array(
            // Must encode as JSON object {}, not array [].
            'fields'    => (object) array(),
            'notices'   => $notices,
            'termsText' => '',
        );
    }

    /**
     * Report Beacon Checkout control status when the sibling plugin is active.
     */
    private function collect_controls() {
        if ( class_exists( 'Beacon_SC_Entitlements' ) && method_exists( 'Beacon_SC_Entitlements', 'controls_snapshot' ) ) {
            return Beacon_SC_Entitlements::controls_snapshot();
        }

        return array(
            'ageGate' => array(
                'enabled'           => false,
                'threshold'         => 0,
                'active'            => false,
                'entryLegalVersion' => '',
                'crawlMode'         => '',
                'source'            => 'unknown',
            ),
            'attestation' => array(
                'enabled'       => false,
                'legalVersion'  => '',
                'gatewayActive' => false,
            ),
            'connect' => array(
                'pluginPresent' => false,
                'paymentsReady' => false,
            ),
            'loginGate' => array(
                'enabled' => false,
                'active'  => false,
                'source'  => 'unknown',
            ),
        );
    }

    /**
     * Which SEO plugin owns the live <title>/<meta description> output.
     * Prefer the active plugin so leftover meta from a previous SEO plugin
     * (e.g. Yoast rows after switching to Rank Math) is not scanned.
     *
     * @return string|null 'rank_math', 'yoast', or null if neither is loaded.
     */
    private function get_active_seo_plugin() {
        if ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath', false ) ) {
            return 'rank_math';
        }
        if ( defined( 'WPSEO_VERSION' ) || class_exists( 'WPSEO_Options', false ) ) {
            return 'yoast';
        }
        return null;
    }

    private function get_meta_title( $post_id ) {
        $yoast    = get_post_meta( $post_id, '_yoast_wpseo_title', true );
        $rankmath = get_post_meta( $post_id, 'rank_math_title', true );
        $active   = $this->get_active_seo_plugin();

        if ( 'rank_math' === $active ) {
            return $rankmath ? $rankmath : '';
        }
        if ( 'yoast' === $active ) {
            return $yoast ? $yoast : '';
        }
        if ( $yoast ) {
            return $yoast;
        }
        if ( $rankmath ) {
            return $rankmath;
        }
        return '';
    }

    private function get_meta_description( $post_id ) {
        $yoast    = get_post_meta( $post_id, '_yoast_wpseo_metadesc', true );
        $rankmath = get_post_meta( $post_id, 'rank_math_description', true );
        $active   = $this->get_active_seo_plugin();

        // When Rank Math (or Yoast) is active, only read that plugin's meta.
        // Do not fall back to the other — orphaned post meta after a plugin
        // switch would otherwise keep flagging text that no longer appears
        // in page source.
        if ( 'rank_math' === $active ) {
            return $rankmath ? $rankmath : '';
        }
        if ( 'yoast' === $active ) {
            return $yoast ? $yoast : '';
        }
        if ( $yoast ) {
            return $yoast;
        }
        if ( $rankmath ) {
            return $rankmath;
        }
        return '';
    }
}
