<?php
/**
 * Uninstall Beacon. Reports the event while license options still exist.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

$api_base = '';
if ( defined( 'CM_API_BASE_URL' ) && CM_API_BASE_URL ) {
    $api_base = rtrim( (string) CM_API_BASE_URL, '/' );
} else {
    $option = get_option( 'cm_api_base_url', '' );
    if ( is_string( $option ) && '' !== trim( $option ) ) {
        $api_base = rtrim( trim( $option ), '/' );
    } else {
        $api_base = 'https://beacon-api-znne.onrender.com';
    }
}

$token = (string) get_option( 'cm_license_token', '' );
$key   = (string) get_option( 'cm_license_key', '' );
if ( '' !== $api_base && ( '' !== $token || '' !== $key ) ) {
    $user  = function_exists( 'wp_get_current_user' ) ? wp_get_current_user() : null;
    $args  = array(
        'timeout' => 8,
        'headers' => array(
            'Content-Type' => 'application/json',
            'Accept'       => 'application/json',
        ),
        'body'    => wp_json_encode(
            array(
                'event'         => 'uninstalled',
                'pluginSlug'    => 'compliance-monitor',
                'pluginVersion' => '1.0.15',
                'siteUrl'       => home_url(),
                'licenseKey'    => $key,
                'actorLogin'    => ( $user && $user->ID ) ? (string) $user->user_login : '',
                'actorEmail'    => ( $user && $user->ID ) ? (string) $user->user_email : '',
            )
        ),
    );
    if ( '' !== $token ) {
        $args['headers']['Authorization'] = 'Bearer ' . $token;
    }
    wp_remote_post( $api_base . '/api/plugins/lifecycle', $args );
}
