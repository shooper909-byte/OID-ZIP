<?php
if ( ! defined( 'ABSPATH' ) ) exit;
$license = CM_License::instance();
?>
<div class="wrap cm-wrap">
    <?php
    cm_render_page_header(
        __( 'License Activation', 'compliance-monitor' ),
        __( 'Enter your Beacon license key to connect this site to the SaaS platform.', 'compliance-monitor' )
    );
    ?>

    <?php
    if ( isset( $_GET['cm_msg'] ) ) {
        $msg = sanitize_text_field( wp_unslash( $_GET['cm_msg'] ) );
        $text = isset( $_GET['cm_text'] ) ? urldecode( sanitize_text_field( wp_unslash( $_GET['cm_text'] ) ) ) : '';
        $type = in_array( $msg, array( 'activated', 'deactivated', 'settings_saved' ), true ) ? 'success' : 'error';
        $message = $text ?: ( 'activated' === $msg ? __( 'License activated.', 'compliance-monitor' ) : ( 'deactivated' === $msg ? __( 'License deactivated.', 'compliance-monitor' ) : __( 'An error occurred.', 'compliance-monitor' ) ) );
        printf( '<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr( $type ), esc_html( $message ) );
    }
    ?>

    <div class="cm-card">
        <h2><?php esc_html_e( 'Current License', 'compliance-monitor' ); ?></h2>
        <table class="form-table">
            <tr>
                <th><?php esc_html_e( 'Status', 'compliance-monitor' ); ?></th>
                <td><span class="cm-status-badge <?php echo esc_attr( $license->get_status_class() ); ?>"><?php echo esc_html( $license->get_status_label() ); ?></span></td>
            </tr>
            <?php if ( $license->get_key() ) : ?>
            <tr>
                <th><?php esc_html_e( 'License Key', 'compliance-monitor' ); ?></th>
                <td><code><?php echo esc_html( substr( $license->get_key(), 0, 8 ) . '••••••••' ); ?></code></td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Plan', 'compliance-monitor' ); ?></th>
                <td><?php echo esc_html( ucfirst( strtolower( $license->get_plan() ?: '—' ) ) ); ?></td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Expires', 'compliance-monitor' ); ?></th>
                <td><?php echo esc_html( get_option( 'cm_license_expires', '—' ) ); ?></td>
            </tr>
            <?php endif; ?>
        </table>
    </div>

    <div class="cm-card">
        <h2><?php esc_html_e( 'API Connection', 'compliance-monitor' ); ?></h2>
        <p class="description"><?php esc_html_e( 'The Beacon SaaS API this site connects to. Set this to your platform API URL before activating a license.', 'compliance-monitor' ); ?></p>
        <?php if ( cm_api_base_url_is_locked() ) : ?>
            <table class="form-table">
                <tr>
                    <th><?php esc_html_e( 'API URL', 'compliance-monitor' ); ?></th>
                    <td>
                        <code><?php echo esc_html( cm_get_api_base_url() ); ?></code>
                        <p class="description"><?php esc_html_e( 'Locked by CM_API_BASE_URL in wp-config.php.', 'compliance-monitor' ); ?></p>
                    </td>
                </tr>
            </table>
        <?php else : ?>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <?php wp_nonce_field( 'cm_save_settings' ); ?>
                <input type="hidden" name="action" value="cm_save_settings">
                <table class="form-table">
                    <tr>
                        <th><label for="cm_api_base_url"><?php esc_html_e( 'API URL', 'compliance-monitor' ); ?></label></th>
                        <td><input type="url" id="cm_api_base_url" name="cm_api_base_url" class="regular-text" value="<?php echo esc_attr( cm_get_api_base_url() ); ?>" placeholder="https://your-api.onrender.com"></td>
                    </tr>
                </table>
                <?php submit_button( __( 'Save API URL', 'compliance-monitor' ), 'secondary' ); ?>
            </form>
        <?php endif; ?>
    </div>

    <div class="cm-card">
        <?php if ( $license->is_active() ) : ?>
            <h2><?php esc_html_e( 'Deactivate License', 'compliance-monitor' ); ?></h2>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <?php wp_nonce_field( 'cm_deactivate_license' ); ?>
                <input type="hidden" name="action" value="cm_deactivate_license">
                <?php submit_button( __( 'Deactivate License', 'compliance-monitor' ), 'delete', 'submit', false ); ?>
            </form>
        <?php else : ?>
            <h2><?php esc_html_e( 'Activate License', 'compliance-monitor' ); ?></h2>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <?php wp_nonce_field( 'cm_activate_license' ); ?>
                <input type="hidden" name="action" value="cm_activate_license">
                <table class="form-table">
                    <tr>
                        <th><label for="cm_license_key"><?php esc_html_e( 'License Key', 'compliance-monitor' ); ?></label></th>
                        <td><input type="text" id="cm_license_key" name="cm_license_key" class="regular-text" value="<?php echo esc_attr( $license->get_key() ); ?>" placeholder="CM-XXXXXXXX"></td>
                    </tr>
                </table>
                <?php submit_button( __( 'Activate License', 'compliance-monitor' ), 'primary' ); ?>
            </form>
        <?php endif; ?>
    </div>
</div>
