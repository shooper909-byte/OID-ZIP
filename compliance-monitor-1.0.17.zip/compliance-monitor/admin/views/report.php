<?php
if ( ! defined( 'ABSPATH' ) ) exit;
$license = CM_License::instance();
$api     = new CM_API_Client();
$scan_id = get_option( 'cm_last_scan_id', '' );
?>
<div class="wrap cm-wrap">
    <?php cm_render_page_header( __( 'Latest Compliance Risk Report', 'compliance-monitor' ) ); ?>

    <?php if ( ! $scan_result ) : ?>
        <div class="cm-card">
            <?php if ( $license->is_active() ) : ?>
                <p><?php esc_html_e( 'No scan results are available yet. Scans are run and scheduled by the Beacon team; your latest report will appear here automatically once a scan completes.', 'compliance-monitor' ); ?></p>
            <?php else : ?>
                <p><?php esc_html_e( 'No scan results are available. Activate your license to enable monitoring.', 'compliance-monitor' ); ?></p>
            <?php endif; ?>
        </div>
    <?php else : ?>

    <div class="cm-card">
        <div class="cm-report-header">
            <p><?php printf( esc_html__( 'Scan Date: %s', 'compliance-monitor' ), esc_html( $last_scan_date ) ); ?></p>
            <div class="cm-report-actions">
                <?php if ( ! empty( $scan_result['pdfUrl'] ) ) : ?>
                <a href="<?php echo esc_url( $scan_result['pdfUrl'] ); ?>" class="button button-primary" target="_blank" rel="noopener">
                    <?php esc_html_e( 'Download PDF Report', 'compliance-monitor' ); ?>
                </a>
                <?php endif; ?>
                <?php if ( $scan_id ) : ?>
                <a href="<?php echo esc_url( $api->get_report_url( $scan_id ) ); ?>" class="button button-secondary" target="_blank" rel="noopener">
                    <?php esc_html_e( 'View HTML Report', 'compliance-monitor' ); ?>
                </a>
                <?php endif; ?>
            </div>
        </div>

        <h2><?php esc_html_e( 'Risk Assessment Scores', 'compliance-monitor' ); ?></h2>
        <div class="cm-scores-grid">
            <?php
            $scores = $scan_result['scores'];
            $score_items = array(
                'overallRiskScore'            => __( 'Overall Risk Score', 'compliance-monitor' ),
                'legalComplianceScore'        => __( 'Legal Compliance', 'compliance-monitor' ),
                'paymentReadinessScore'       => __( 'Processor Readiness', 'compliance-monitor' ),
                'certificationReadinessScore' => __( 'Certification Readiness', 'compliance-monitor' ),
                'bestPracticesScore'          => __( 'Best Practices', 'compliance-monitor' ),
            );
            foreach ( $score_items as $key => $label ) :
                $value = isset( $scores[ $key ] ) ? $scores[ $key ] : '—';
            ?>
            <div class="cm-score-item">
                <span class="cm-score-label"><?php echo esc_html( $label ); ?></span>
                <span class="cm-score-value"><?php echo esc_html( $value ); ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="cm-card">
        <?php
        $findings        = cm_sort_findings_by_severity( $scan_result['findings'] );
        $severity_counts = cm_count_findings_by_severity( $findings );
        $severity_labels = array(
            'CRITICAL' => __( 'Critical', 'compliance-monitor' ),
            'HIGH'     => __( 'High', 'compliance-monitor' ),
            'MEDIUM'   => __( 'Medium', 'compliance-monitor' ),
            'LOW'      => __( 'Low', 'compliance-monitor' ),
        );
        ?>
        <h2><?php esc_html_e( 'Findings', 'compliance-monitor' ); ?>
            <span class="cm-findings-count">(<?php echo count( $findings ); ?>)</span>
        </h2>

        <?php if ( empty( $findings ) ) : ?>
            <p><?php esc_html_e( 'No compliance risk findings detected.', 'compliance-monitor' ); ?></p>
        <?php else : ?>
            <ul class="cm-severity-summary">
                <?php foreach ( $severity_labels as $severity_key => $severity_label ) : ?>
                    <?php if ( empty( $severity_counts[ $severity_key ] ) ) { continue; } ?>
                    <li>
                        <span class="cm-severity-badge <?php echo esc_attr( CM_Admin::instance()->get_severity_class( $severity_key ) ); ?>">
                            <?php echo esc_html( $severity_label ); ?>
                        </span>
                        <span class="cm-severity-summary-count"><?php echo esc_html( (string) $severity_counts[ $severity_key ] ); ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
            <p class="cm-findings-sort-note"><?php esc_html_e( 'Sorted by severity (highest risk first).', 'compliance-monitor' ); ?></p>

            <table class="wp-list-table widefat fixed striped cm-findings-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Severity', 'compliance-monitor' ); ?></th>
                        <th><?php esc_html_e( 'Finding', 'compliance-monitor' ); ?></th>
                        <th><?php esc_html_e( 'Category', 'compliance-monitor' ); ?></th>
                        <th><?php esc_html_e( 'Affected', 'compliance-monitor' ); ?></th>
                        <th><?php esc_html_e( 'Recommended Fix', 'compliance-monitor' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $findings as $finding ) : ?>
                    <tr>
                        <td><span class="cm-severity-badge <?php echo esc_attr( CM_Admin::instance()->get_severity_class( $finding['severity'] ) ); ?>"><?php echo esc_html( $finding['severity'] ); ?></span></td>
                        <td>
                            <strong><?php echo esc_html( $finding['title'] ); ?></strong>
                            <p class="cm-finding-desc"><?php echo esc_html( $finding['description'] ); ?></p>
                            <?php if ( ! empty( $finding['evidence'] ) ) : ?>
                                <p class="cm-evidence"><em><?php esc_html_e( 'Evidence:', 'compliance-monitor' ); ?></em> <?php echo esc_html( $finding['evidence'] ); ?></p>
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html( str_replace( '_', ' ', $finding['category'] ) ); ?></td>
                        <td>
                            <?php if ( ! empty( $finding['affectedUrl'] ) ) : ?>
                                <a href="<?php echo esc_url( $finding['affectedUrl'] ); ?>" target="_blank"><?php echo esc_html( $finding['affectedObject'] ?: $finding['affectedUrl'] ); ?></a>
                            <?php else : ?>
                                <?php echo esc_html( $finding['affectedObject'] ?: '—' ); ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo esc_html( $finding['recommendation'] ); ?>
                            <?php if ( ! empty( $finding['suggestedReplacementText'] ) ) : ?>
                                <p class="cm-suggestion"><strong><?php esc_html_e( 'Suggested:', 'compliance-monitor' ); ?></strong> <?php echo esc_html( $finding['suggestedReplacementText'] ); ?></p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div class="cm-disclaimer">
        <p><strong><?php esc_html_e( 'Disclaimer:', 'compliance-monitor' ); ?></strong>
        <?php esc_html_e( 'This report is a risk-assessment tool and does not constitute legal advice, regulatory approval, processor approval, or certification approval. Final compliance responsibility remains with the merchant.', 'compliance-monitor' ); ?></p>
    </div>

    <?php endif; ?>
</div>
