<?php
if ( ! defined( 'ABSPATH' ) ) exit;
$license = CM_License::instance();
?>
<div class="wrap cm-wrap">
    <?php
    cm_render_page_header(
        __( 'Dashboard', 'compliance-monitor' ),
        __( 'Compliance risk monitoring for your WooCommerce store. Final compliance responsibility remains with the merchant.', 'compliance-monitor' )
    );
    ?>

    <?php cm_render_admin_notices(); ?>

    <div class="cm-grid">
        <div class="cm-card">
            <h2><?php esc_html_e( 'License Status', 'compliance-monitor' ); ?></h2>
            <p class="cm-status-badge <?php echo esc_attr( $license->get_status_class() ); ?>">
                <?php echo esc_html( $license->get_status_label() ); ?>
            </p>
            <?php if ( $license->is_active() ) : ?>
                <p><?php printf( esc_html__( 'Plan: %s', 'compliance-monitor' ), esc_html( ucfirst( strtolower( $license->get_plan() ) ) ) ); ?></p>
            <?php else : ?>
                <p class="cm-renewal-notice">
                    <?php esc_html_e( 'Your license is inactive. Monitoring is disabled. Please activate or renew your license.', 'compliance-monitor' ); ?>
                </p>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=compliance-monitor-license' ) ); ?>" class="button button-primary">
                    <?php esc_html_e( 'Activate License', 'compliance-monitor' ); ?>
                </a>
            <?php endif; ?>
        </div>

        <div class="cm-card">
            <h2><?php esc_html_e( 'Managed Compliance Monitoring', 'compliance-monitor' ); ?></h2>
            <?php if ( $license->is_active() ) : ?>
                <p><?php esc_html_e( 'Your store is monitored by the Beacon team. Scans are run and scheduled centrally on your behalf — there is nothing to start here. The latest results appear below and in the Latest Report screen as soon as a scan completes.', 'compliance-monitor' ); ?></p>
            <?php else : ?>
                <p class="cm-disabled"><?php esc_html_e( 'Monitoring is disabled until a valid license is activated.', 'compliance-monitor' ); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <?php if ( $scan_result ) : ?>
    <div class="cm-card cm-scores-card">
        <h2><?php esc_html_e( 'Latest Risk Assessment Scores', 'compliance-monitor' ); ?></h2>
        <p class="cm-scan-date">
            <?php
            printf(
                esc_html__( 'Last scan: %s', 'compliance-monitor' ),
                esc_html( $last_scan_date )
            );
            ?>
        </p>
        <div class="cm-scores-grid">
            <?php
            $scores = $scan_result['scores'];
            $score_items = array(
                'overallRiskScore'            => __( 'Overall Risk Score', 'compliance-monitor' ),
                'legalComplianceScore'        => __( 'Legal Compliance', 'compliance-monitor' ),
                'paymentReadinessScore'       => __( 'Processor Readiness', 'compliance-monitor' ),
                'certificationReadinessScore' => __( 'Certification Readiness', 'compliance-monitor' ),
                'bestPracticesScore'          => __( 'Best Practices', 'compliance-monitor' ),
            );
            foreach ( $score_items as $key => $label ) :
                $value = isset( $scores[ $key ] ) ? $scores[ $key ] : '—';
            ?>
            <div class="cm-score-item">
                <span class="cm-score-label"><?php echo esc_html( $label ); ?></span>
                <span class="cm-score-value"><?php echo esc_html( $value ); ?></span>
            </div>
            <?php endforeach; ?>
        </div>
        <p>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=compliance-monitor-report' ) ); ?>" class="button">
                <?php esc_html_e( 'View Latest Report', 'compliance-monitor' ); ?>
            </a>
        </p>
    </div>
    <?php endif; ?>

    <div class="cm-disclaimer">
        <p><strong><?php esc_html_e( 'Disclaimer:', 'compliance-monitor' ); ?></strong>
        <?php esc_html_e( 'This tool provides compliance risk monitoring and risk assessment only. It does not constitute legal advice, regulatory approval, processor approval, or certification approval.', 'compliance-monitor' ); ?></p>
    </div>
</div>
