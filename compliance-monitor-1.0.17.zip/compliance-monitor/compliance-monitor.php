<?php
/**
 * Plugin Name: Beacon
 * Plugin URI: https://testamenttechnologies.com/beacon
 * Description: WooCommerce compliance risk monitoring for Research Use Only and high-risk eCommerce websites. Connects to the Beacon SaaS platform by Testament Technologies for server-side analysis.
 * Version: 1.0.17
 * Author: Testament Technologies
 * Author URI: https://testamenttechnologies.com
 * License: GPL v2 or later
 * Text Domain: compliance-monitor
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * WC requires at least: 7.0
 * WC tested up to: 9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'CM_VERSION', '1.0.17' );
define( 'CM_PLUGIN_FILE', __FILE__ );
define( 'CM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CM_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

// Production Beacon SaaS API endpoint the plugin points at out of the box.
define( 'CM_DEFAULT_API_BASE_URL', 'https://beacon-api-znne.onrender.com' );

// The API base URL is resolved at runtime by cm_get_api_base_url(): the
// CM_API_BASE_URL wp-config.php constant wins if set, otherwise the value saved
// on the Beacon → License screen, otherwise CM_DEFAULT_API_BASE_URL above. We do
// not force a constant here so the admin setting can take effect.
// To pin it via hosting config, add to wp-config.php:
//   define( 'CM_API_BASE_URL', 'https://your-api.onrender.com' );

require_once CM_PLUGIN_DIR . 'includes/helpers.php';
require_once CM_PLUGIN_DIR . 'includes/class-api-client.php';
require_once CM_PLUGIN_DIR . 'includes/class-license.php';
require_once CM_PLUGIN_DIR . 'includes/class-data-collector.php';
require_once CM_PLUGIN_DIR . 'includes/class-scheduler.php';
require_once CM_PLUGIN_DIR . 'includes/class-collect-worker.php';
require_once CM_PLUGIN_DIR . 'includes/class-rest.php';
require_once CM_PLUGIN_DIR . 'includes/class-admin.php';
require_once CM_PLUGIN_DIR . 'includes/class-prepublish-guard.php';
require_once CM_PLUGIN_DIR . 'includes/class-beacon-updater.php';

Beacon_Remote_Updater::register(
    array(
        'slug'             => 'compliance-monitor',
        'plugin_basename'  => CM_PLUGIN_BASENAME,
        'version'          => CM_VERSION,
        'api_base'         => 'cm_get_api_base_url',
        'license_token'    => static function () {
            return (string) get_option( 'cm_license_token', '' );
        },
        'license_key'      => static function () {
            return (string) get_option( 'cm_license_key', '' );
        },
    )
);

/**
 * Main plugin bootstrap.
 */
final class Compliance_Monitor {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action(
            'before_woocommerce_init',
            static function () {
                if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
                    \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
                        'custom_order_tables',
                        CM_PLUGIN_FILE,
                        true
                    );
                }
            }
        );

        add_action( 'plugins_loaded', array( $this, 'init' ) );
        register_activation_hook( CM_PLUGIN_FILE, array( $this, 'activate' ) );
        register_deactivation_hook( CM_PLUGIN_FILE, array( $this, 'deactivate' ) );
        add_action( 'activated_plugin', array( $this, 'on_plugin_activated' ), 10, 1 );
        add_action( 'deactivated_plugin', array( $this, 'on_plugin_deactivated' ), 10, 1 );
        add_action( 'deleted_plugin', array( $this, 'on_plugin_deleted' ), 10, 2 );
        add_action( 'upgrader_process_complete', array( $this, 'on_upgrader_complete' ), 10, 2 );
    }

    public function init() {
        if ( ! $this->is_woocommerce_active() ) {
            add_action( 'admin_notices', array( $this, 'woocommerce_missing_notice' ) );
            return;
        }

        CM_License::instance();
        CM_Scheduler::instance();
        CM_Collect_Worker::instance();
        CM_Rest::instance();
        CM_Admin::instance();
        CM_Prepublish_Guard::instance();
    }

    public function activate() {
        if ( ! $this->is_woocommerce_active() ) {
            deactivate_plugins( CM_PLUGIN_BASENAME );
            wp_die(
                esc_html__( 'Beacon requires WooCommerce to be installed and active.', 'compliance-monitor' ),
                esc_html__( 'Plugin Activation Error', 'compliance-monitor' ),
                array( 'back_link' => true )
            );
        }

        add_option( 'cm_license_key', '' );
        add_option( 'cm_license_status', 'inactive' );
        add_option( 'cm_license_token', '' );
        add_option( 'cm_license_plan', '' );
        add_option( 'cm_license_scan_frequency', '' );
        add_option( 'cm_license_expires', '' );
        add_option( 'cm_last_scan_id', '' );
        add_option( 'cm_last_scan_result', '' );
        add_option( 'cm_last_scan_date', '' );
        add_option( 'cm_last_scan_completed_at', '' );

        // Scans are initiated and scheduled centrally from the SaaS dashboard.
        // Remove any legacy merchant-side scheduled scan events.
        CM_Scheduler::unschedule();
        CM_Collect_Worker::instance()->ensure_schedule();
        if ( function_exists( 'cm_report_lifecycle_event' ) ) {
            cm_report_lifecycle_event( 'activated' );
        }
    }

    public function deactivate() {
        if ( function_exists( 'cm_report_lifecycle_event' ) ) {
            cm_report_lifecycle_event( 'deactivated' );
        }
        delete_option( 'cm_license_token' );
        CM_Scheduler::unschedule();
        CM_Collect_Worker::unschedule();
    }

    /**
     * @param string $plugin Plugin basename.
     */
    public function on_plugin_activated( $plugin ) {
        if ( CM_PLUGIN_BASENAME === $plugin ) {
            return;
        }
        if ( function_exists( 'cm_report_wp_plugin_event' ) ) {
            cm_report_wp_plugin_event( 'activated', $plugin );
        }
    }

    /**
     * @param string $plugin Plugin basename.
     */
    public function on_plugin_deactivated( $plugin ) {
        if ( CM_PLUGIN_BASENAME === $plugin ) {
            return;
        }
        if ( function_exists( 'cm_report_wp_plugin_event' ) ) {
            cm_report_wp_plugin_event( 'deactivated', $plugin );
        }
    }

    /**
     * @param string $plugin Plugin basename.
     * @param bool   $deleted Whether the plugin was deleted.
     */
    public function on_plugin_deleted( $plugin, $deleted ) {
        if ( ! $deleted || CM_PLUGIN_BASENAME === $plugin ) {
            return;
        }
        if ( function_exists( 'cm_report_wp_plugin_event' ) ) {
            cm_report_wp_plugin_event( 'uninstalled', $plugin );
        }
    }

    /**
     * @param \WP_Upgrader $upgrader Upgrader instance.
     * @param array        $hook_extra Hook extra.
     */
    public function on_upgrader_complete( $upgrader, $hook_extra ) {
        if ( ! is_array( $hook_extra ) || ( isset( $hook_extra['type'] ) ? $hook_extra['type'] : '' ) !== 'plugin' ) {
            return;
        }
        $action = isset( $hook_extra['action'] ) ? $hook_extra['action'] : '';
        if ( 'install' === $action ) {
            $basename = '';
            if ( ! empty( $hook_extra['plugin'] ) ) {
                $basename = (string) $hook_extra['plugin'];
            } elseif ( is_object( $upgrader ) && method_exists( $upgrader, 'plugin_info' ) ) {
                $basename = (string) $upgrader->plugin_info();
            }
            if ( $basename && CM_PLUGIN_BASENAME !== $basename && function_exists( 'cm_report_wp_plugin_event' ) ) {
                cm_report_wp_plugin_event( 'installed', $basename );
            }
        } elseif ( 'update' === $action ) {
            $plugins = array();
            if ( ! empty( $hook_extra['plugins'] ) && is_array( $hook_extra['plugins'] ) ) {
                $plugins = $hook_extra['plugins'];
            } elseif ( ! empty( $hook_extra['plugin'] ) ) {
                $plugins = array( $hook_extra['plugin'] );
            }
            foreach ( $plugins as $basename ) {
                if ( CM_PLUGIN_BASENAME === $basename ) {
                    continue;
                }
                if ( function_exists( 'cm_report_wp_plugin_event' ) ) {
                    cm_report_wp_plugin_event( 'updated', $basename );
                }
            }
        }
    }

    private function is_woocommerce_active() {
        return class_exists( 'WooCommerce' );
    }

    public function woocommerce_missing_notice() {
        ?>
        <div class="notice notice-error">
            <p><?php esc_html_e( 'Beacon requires WooCommerce to be installed and active.', 'compliance-monitor' ); ?></p>
        </div>
        <?php
    }
}

Compliance_Monitor::instance();
